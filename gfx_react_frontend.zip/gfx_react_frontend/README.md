# GFX Threshold Deviation Dashboard - React Frontend

This is a complete React.js frontend implementation for the GFX Threshold Deviation Dashboard.

## Features

- **Modern React 18.2.0 Implementation**: Built with the latest React patterns and hooks
- **Ant Design UI Components**: Professional, enterprise-grade user interface
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Real-time Data Integration**: Connects to Flask API backend for live data
- **Comprehensive Dashboard Views**: 
  - Simplified mode with 3-row layout
  - Advanced mode with detailed analytics
- **Interactive Components**:
  - Configurable sidebar with data source selection
  - Threshold management with inline editing
  - Reason code analysis with drill-down capabilities
  - Deviation bucket visualization
- **Chart Integration**: Interactive charts using Recharts library

## Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm start
   ```

3. **Access the Dashboard**
   Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

```
src/
├── components/
│   ├── Sidebar.js              # Configuration sidebar
│   ├── Dashboard.js            # Main dashboard container
│   ├── SimplifiedDashboard.js  # 3-row simplified view
│   ├── AdvancedDashboard.js    # Advanced analytics view
│   ├── ThresholdTable.js       # Threshold management
│   ├── ReasonCodeAnalysis.js   # Reason code breakdown
│   └── DeviationBuckets.js     # Deviation bucket analysis
├── services/
│   ├── DataService.js          # API integration service
│   └── ApiService.js           # HTTP client wrapper
├── App.js                      # Main application component
├── App.css                     # Application styles
└── index.js                    # React entry point
```

## Configuration

### API Backend
The frontend expects a Flask API backend running on `http://localhost:5000`. 

Key API endpoints:
- `POST /api/load-sample-data` - Load sample trading data
- `POST /api/process-thresholds` - Process threshold configurations
- `POST /api/run-impact-analysis` - Run impact analysis
- `POST /api/export-data` - Export analysis results

### Environment Variables
Create a `.env` file in the root directory:

```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_ENVIRONMENT=development
```

## Available Scripts

- `npm start` - Runs the app in development mode
- `npm build` - Builds the app for production
- `npm test` - Launches the test runner
- `npm eject` - Ejects from Create React App (one-way operation)

## Dashboard Features

### Simplified Dashboard Mode
- **Row 1**: Threshold Configuration & Impact Analysis
  - Currency-wise and group-wise threshold management
  - Real-time impact analysis results
  - Inline threshold editing capabilities

- **Row 2**: Reason Code Mapping & Analysis  
  - High-level reason code breakdown
  - Detailed exception status tracking
  - Operations workflow analysis

- **Row 3**: Deviation Bucket Analysis
  - Grouped deviation summaries
  - Currency-wise alert distribution
  - Interactive drill-down capabilities

### Advanced Dashboard Mode
- Comprehensive analytics with multiple chart types
- Detailed data tables with sorting and filtering
- Export functionality for analysis results
- Performance metrics and KPI tracking

### Data Sources
- **Sample Data**: Pre-loaded comprehensive test dataset
- **API Integration**: Real-time data from external APIs
- **Manual Upload**: CSV file upload for custom datasets

## Dependencies

### Core Dependencies
- `react` (^18.2.0) - React library
- `react-dom` (^18.2.0) - React DOM bindings
- `react-scripts` (5.0.1) - Create React App scripts

### UI & Visualization
- `antd` (^5.12.0) - Ant Design components
- `@ant-design/icons` (^5.2.6) - Ant Design icons
- `recharts` (^2.8.0) - Chart library
- `moment` (^2.29.4) - Date manipulation

### HTTP & Data
- `axios` (^1.6.0) - HTTP client

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Deployment

### Development
```bash
npm start
```

### Production Build
```bash
npm run build
```

The build folder will contain the production-ready static files.

### Docker Deployment
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## Contributing

1. Clone the repository
2. Install dependencies: `npm install`
3. Start development server: `npm start`
4. Make your changes
5. Test thoroughly
6. Submit a pull request

## License

This project is part of the GFX Threshold Deviation Dashboard system.

## Support

For technical support or questions about the React frontend implementation, please refer to the project documentation or contact the development team.

---

**Note**: This React frontend is designed to work with the Python Flask backend API. Ensure the backend server is running before starting the frontend application.