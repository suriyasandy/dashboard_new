import streamlit as st
from datetime import date, timedelta
from utils.helpers import get_default_date_range, validate_date_range

def render_sidebar():
    """Render sidebar with configuration options"""
    
    st.sidebar.header("🔧 Configuration")
    
    # Dashboard Mode Selection
    st.sidebar.subheader("🎛️ Dashboard Mode")
    dashboard_mode = st.sidebar.radio(
        "Select Dashboard:",
        options=["Simplified Dashboard", "Advanced Dashboard"],
        index=0,
        help="Choose dashboard interface type"
    )
    st.session_state.dashboard_mode = dashboard_mode
    
    # Data source configuration
    st.sidebar.subheader("📊 Data Sources")
    
    # Data source mode selection
    data_source_mode = st.sidebar.radio(
        "Data Source Mode",
        options=["Sample Data", "API", "Manual Upload"],
        index=0,
        help="Choose data source: Sample for testing, API for production, Manual for file upload"
    )
    
    # Load available options based on data source
    if data_source_mode == "Sample Data":
        from utils.enhanced_sample_loader import EnhancedSampleLoader
        loader = EnhancedSampleLoader()
        available_options = loader.get_available_options()
        
        # Display sample data info
        file_info = loader.check_sample_data_availability()
        st.sidebar.success(f"📊 {file_info['trade_files_count']} trade files available")
        
        # Product type selection
        product_types = st.sidebar.multiselect(
            "Product Types",
            options=available_options.get('product_types', ["FX_SPOT", "FX_FORWARD", "FX_SWAP", "FX_OPTION"]),
            default=available_options.get('product_types', ["FX_SPOT"])[:1],
            help="Select product types to analyze"
        )
    else:
        # Product type selection for API/Manual modes
        product_types = st.sidebar.multiselect(
            "Product Types",
            options=["FX_SPOT", "FX_FORWARD", "FX_SWAP", "FX_OPTION"],
            default=["FX_SPOT"],
            help="Select product types to analyze"
        )
    
    # Legal entity and source system selection based on data source
    if data_source_mode == "Sample Data":
        # Legal entity selection
        legal_entities = st.sidebar.multiselect(
            "Legal Entities",
            options=available_options.get('legal_entities', ["Entity1", "Entity2", "Entity3"]),
            default=available_options.get('legal_entities', ["Entity1"])[:1],
            help="Select legal entities to include"
        )
        
        # Source system selection
        source_systems = st.sidebar.multiselect(
            "Source Systems",
            options=available_options.get('source_systems', ["SYSTEM_A", "SYSTEM_B", "SYSTEM_C"]),
            default=available_options.get('source_systems', ["SYSTEM_A"])[:1],
            help="Select source systems to analyze"
        )
    else:
        # Legal entity selection for API/Manual modes
        legal_entities = st.sidebar.multiselect(
            "Legal Entities",
            options=["Entity1", "Entity2", "Entity3", "ALL"],
            default=["Entity1"],
            help="Select legal entities to include"
        )
        
        # Source system selection
        source_systems = st.sidebar.multiselect(
            "Source Systems",
            options=["SYSTEM_A", "SYSTEM_B", "SYSTEM_C"],
            default=["SYSTEM_A"],
            help="Select source systems to analyze"
        )
    
    # Date range selection
    st.sidebar.subheader("📅 Date Range")
    
    if data_source_mode == "Sample Data" and available_options.get('date_range'):
        # Use sample data date range
        sample_start, sample_end = available_options['date_range']
        default_start, default_end = sample_start, sample_end
        st.sidebar.info(f"Sample data range: {sample_start} to {sample_end}")
    else:
        default_start, default_end = get_default_date_range()
    
    start_date = st.sidebar.date_input(
        "Start Date",
        value=default_start,
        max_value=date.today() if data_source_mode != "Sample Data" else sample_end,
        help="Start date for data analysis"
    )
    
    end_date = st.sidebar.date_input(
        "End Date",
        value=default_end,
        max_value=date.today(),
        help="End date for data analysis"
    )
    
    # Validate date range
    date_errors = validate_date_range(start_date, end_date)
    if date_errors:
        for error in date_errors:
            st.sidebar.error(error)
    
    # Threshold configuration
    st.sidebar.subheader("🎯 Threshold Configuration")
    
    # Threshold mode selection
    threshold_mode = st.sidebar.radio(
        "Threshold Mode",
        options=["group", "currency"],
        index=0,
        help="Choose between group-wise or currency-wise thresholding"
    )
    
    # Threshold file upload
    threshold_file = st.sidebar.file_uploader(
        "Upload Threshold File",
        type=['csv'],
        help="Upload CSV file with threshold configurations"
    )
    
    if threshold_file is not None:
        st.sidebar.success("✅ Threshold file uploaded")
    
    # Reason code configuration
    st.sidebar.subheader("📋 Reason Code Mapping")
    
    reason_code_file = st.sidebar.file_uploader(
        "Upload Reason Code File",
        type=['csv'],
        help="Upload CSV file with reason code to high-level code mappings"
    )
    
    if reason_code_file is not None:
        st.sidebar.success("✅ Reason code file uploaded")
    
    # Manual file upload section (if manual mode selected)
    trade_files = {}
    exception_file = None
    
    if data_source_mode == "Manual Upload":
        st.sidebar.subheader("📁 Trade Data Files")
        st.sidebar.info("Upload one file per Product Type + Legal Entity + Source System combination")
        
        # Generate file upload fields based on selections
        if product_types and legal_entities and source_systems:
            for product_type in product_types:
                for legal_entity in legal_entities:
                    for source_system in source_systems:
                        file_key = f"{product_type}_{legal_entity}_{source_system}"
                        uploaded_file = st.sidebar.file_uploader(
                            f"{product_type} - {legal_entity} - {source_system}",
                            type=['csv'],
                            key=f"trade_file_{file_key}",
                            help=f"Upload {product_type} data for {legal_entity} from {source_system}"
                        )
                        if uploaded_file is not None:
                            trade_files[file_key] = uploaded_file
        
        # Exception data file upload
        st.sidebar.subheader("📋 Exception Data")
        exception_file = st.sidebar.file_uploader(
            "Exception Data File",
            type=['csv'],
            key="exception_file",
            help="Upload exception data file"
        )
        
        if exception_file is not None:
            st.sidebar.success("✅ Exception file uploaded")
        
        # Show file upload status
        if product_types and legal_entities and source_systems:
            expected_files = len(product_types) * len(legal_entities) * len(source_systems)
            uploaded_files = len(trade_files)
            
            if uploaded_files > 0:
                if uploaded_files == expected_files:
                    st.sidebar.success(f"✅ All {expected_files} trade files uploaded")
                else:
                    st.sidebar.warning(f"⚠️ {uploaded_files}/{expected_files} trade files uploaded")
                    
                    # Show which files are missing
                    missing_combinations = []
                    for product_type in product_types:
                        for legal_entity in legal_entities:
                            for source_system in source_systems:
                                file_key = f"{product_type}_{legal_entity}_{source_system}"
                                if file_key not in trade_files:
                                    missing_combinations.append(f"{product_type}-{legal_entity}-{source_system}")
                    
                    if missing_combinations:
                        st.sidebar.info(f"Missing: {', '.join(missing_combinations[:5])}")
                        if len(missing_combinations) > 5:
                            st.sidebar.info(f"... and {len(missing_combinations) - 5} more")
            else:
                st.sidebar.info(f"📁 Please upload {expected_files} trade files")
    
    # Data loading controls
    st.sidebar.subheader("🔄 Data Loading")
    
    col1, col2 = st.sidebar.columns(2)
    
    with col1:
        load_data_btn = st.button(
            "Load Data",
            type="primary",
            help="Load trade and exception data"
        )
    
    with col2:
        refresh_data_btn = st.button(
            "Refresh",
            help="Refresh all data"
        )
    
    # Advanced options
    with st.sidebar.expander("⚙️ Advanced Options"):
        
        # Parallel processing settings
        max_workers = st.slider(
            "Max Workers (Parallel Downloads)",
            min_value=1,
            max_value=10,
            value=5,
            help="Number of parallel threads for data downloads"
        )
        
        # Bucket configuration
        bucket_size = st.number_input(
            "Expanded Bucket Size",
            min_value=0.1,
            max_value=5.0,
            value=0.5,
            step=0.1,
            help="Bin size for expanded bucket analysis"
        )
        
        # Export format preference
        export_format = st.selectbox(
            "Default Export Format",
            options=["csv", "excel"],
            index=0,
            help="Default format for data exports"
        )
    
    # Determine if data should be loaded
    data_loaded = False
    
    if load_data_btn:
        # Validate configuration based on data source mode
        config_valid = not date_errors and product_types and legal_entities and source_systems
        
        if data_source_mode == "Manual Upload":
            # Additional validation for manual upload mode
            expected_files = len(product_types) * len(legal_entities) * len(source_systems) if product_types and legal_entities and source_systems else 0
            uploaded_files = len(trade_files)
            
            if config_valid and uploaded_files == expected_files:
                data_loaded = True
                st.session_state.data_loaded = True
                st.session_state.refresh_data = True
                st.session_state.refresh_exception_data = True
            elif uploaded_files < expected_files:
                st.sidebar.error(f"Please upload all {expected_files} required trade files")
            else:
                st.sidebar.error("Please fix configuration errors before loading data")
        else:
            # API mode validation
            if config_valid:
                data_loaded = True
                st.session_state.data_loaded = True
                st.session_state.refresh_data = True
                st.session_state.refresh_exception_data = True
            else:
                st.sidebar.error("Please fix configuration errors before loading data")
    
    if refresh_data_btn:
        st.session_state.refresh_data = True
        st.session_state.refresh_exception_data = True
        data_loaded = st.session_state.get('data_loaded', False)
    
    # Status indicators
    st.sidebar.subheader("📊 Status")
    
    # Data status
    trade_data_count = len(st.session_state.get('trade_data', []))
    exception_data_count = len(st.session_state.get('exception_data', []))
    alerts_count = len(st.session_state.get('alerts_df', []))
    
    st.sidebar.metric("Trade Records", trade_data_count)
    st.sidebar.metric("Exception Records", exception_data_count)
    st.sidebar.metric("Current Alerts", alerts_count)
    
    # Return configuration data
    return {
        'product_types': product_types,
        'legal_entities': legal_entities,
        'source_systems': source_systems,
        'start_date': start_date,
        'end_date': end_date,
        'threshold_mode': threshold_mode,
        'threshold_file': threshold_file,
        'reason_code_file': reason_code_file,
        'data_source_mode': data_source_mode,
        'trade_files': trade_files,
        'exception_file': exception_file,
        'data_loaded': data_loaded,
        'max_workers': max_workers,
        'bucket_size': bucket_size,
        'export_format': export_format,
        'date_errors': date_errors
    }
