import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from utils.helpers import format_number, format_percentage

def render_dashboard():
    """Render main dashboard with summary metrics and visualizations"""
    
    # Enhanced header with key status indicators
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        st.title("🔍 GFX Threshold Deviation Dashboard")
        st.caption("Ops Team - Trade Alert Analysis with Configurable Thresholds and Reason Code Workflow")
    
    with col2:
        if st.session_state.get('trade_data', pd.DataFrame()).empty:
            st.metric("Status", "No Data", "Configure & Load")
        else:
            st.metric("Data Status", "Active", "✓ Ready")
    
    with col3:
        last_updated = st.session_state.get('last_updated', 'Never')
        st.metric("Last Updated", last_updated if last_updated != 'Never' else 'N/A')
    
    # Check if data is available
    trade_data = st.session_state.get('trade_data', pd.DataFrame())
    alerts_df = st.session_state.get('alerts_df', pd.DataFrame())
    legal_entity_summary = st.session_state.get('legal_entity_summary', pd.DataFrame())
    ops_analysis = st.session_state.get('ops_analysis', pd.DataFrame())
    
    if trade_data.empty:
        st.info("📊 Load data to view dashboard metrics")
        return
    
    # Quick summary bar
    render_quick_summary_bar(trade_data, alerts_df)
    
    # Main dashboard tabs for better organization
    tab1, tab2, tab3, tab4 = st.tabs([
        "📊 Overview & Analytics", 
        "🔍 Deviation Analysis", 
        "🏢 Legal Entity Impact",
        "⚙️ Ops Workflow"
    ])
    
    with tab1:
        render_overview_tab(trade_data, alerts_df, legal_entity_summary, ops_analysis)
    
    with tab2:
        render_deviation_analysis_tab(alerts_df)
    
    with tab3:
        render_legal_entity_tab(legal_entity_summary, alerts_df)
    
    with tab4:
        render_ops_workflow_tab(ops_analysis, alerts_df)

def render_summary_metrics(trade_data, alerts_df, ops_analysis):
    """Render summary metrics cards"""
    
    # Calculate key metrics
    total_trades = len(trade_data)
    total_alerts = len(alerts_df)
    alert_rate = (total_alerts / total_trades * 100) if total_trades > 0 else 0
    
    avg_deviation = alerts_df['deviationpercent'].mean() if not alerts_df.empty else 0
    max_deviation = alerts_df['deviationpercent'].max() if not alerts_df.empty else 0
    
    closed_trades = len(ops_analysis) if not ops_analysis.empty else 0
    closure_rate = (closed_trades / total_alerts * 100) if total_alerts > 0 else 0
    
    # Display metrics in columns
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="📈 Total Trades",
            value=f"{total_trades:,}",
            help="Total number of trades analyzed"
        )
    
    with col2:
        st.metric(
            label="🚨 Total Alerts",
            value=f"{total_alerts:,}",
            delta=f"{alert_rate:.1f}% of trades",
            help="Number of trades exceeding thresholds"
        )
    
    with col3:
        st.metric(
            label="📊 Avg Deviation",
            value=f"{avg_deviation:.2f}%",
            delta=f"Max: {max_deviation:.2f}%",
            help="Average deviation percentage for alerts"
        )
    
    with col4:
        st.metric(
            label="✅ Closed Trades",
            value=f"{closed_trades:,}",
            delta=f"{closure_rate:.1f}% closure rate",
            help="Alerts processed by ops team"
        )
    
    st.markdown("---")

def render_visualizations(alerts_df, legal_entity_summary, ops_analysis):
    """Render dashboard visualizations"""
    
    if alerts_df.empty:
        st.info("📊 No alerts data available for visualization")
        return
    
    # Create tabs for different visualization sections
    tab1, tab2, tab3, tab4 = st.tabs([
        "🎯 Deviation Analysis", 
        "🏢 Legal Entity Impact", 
        "📋 Ops Workflow", 
        "💱 Currency Analysis"
    ])
    
    with tab1:
        render_deviation_analysis(alerts_df)
    
    with tab2:
        render_legal_entity_analysis(legal_entity_summary)
    
    with tab3:
        render_ops_workflow_analysis(ops_analysis)
    
    with tab4:
        render_currency_analysis(alerts_df)

def render_deviation_analysis(alerts_df):
    """Render deviation analysis visualizations"""
    
    st.subheader("📊 Deviation Distribution Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Deviation histogram
        fig_hist = px.histogram(
            alerts_df,
            x='deviationpercent',
            nbins=20,
            title="Distribution of Deviation Percentages",
            labels={'deviationpercent': 'Deviation %', 'count': 'Number of Alerts'}
        )
        fig_hist.update_layout(showlegend=False)
        st.plotly_chart(fig_hist, use_container_width=True)
    
    with col2:
        # Box plot by legal entity
        if 'legal_entity' in alerts_df.columns:
            fig_box = px.box(
                alerts_df,
                x='legal_entity',
                y='deviationpercent',
                title="Deviation by Legal Entity",
                labels={'deviationpercent': 'Deviation %', 'legal_entity': 'Legal Entity'}
            )
            fig_box.update_xaxes(tickangle=45)
            st.plotly_chart(fig_box, use_container_width=True)
    
    # Threshold vs deviation scatter plot
    if 'threshold_used' in alerts_df.columns:
        fig_scatter = px.scatter(
            alerts_df,
            x='threshold_used',
            y='deviationpercent',
            color='legal_entity' if 'legal_entity' in alerts_df.columns else None,
            title="Deviation vs Threshold Used",
            labels={'threshold_used': 'Threshold Used %', 'deviationpercent': 'Deviation %'},
            hover_data=['trade_id'] if 'trade_id' in alerts_df.columns else None
        )
        
        # Add diagonal line showing threshold boundary
        max_val = max(alerts_df['threshold_used'].max(), alerts_df['deviationpercent'].max())
        fig_scatter.add_shape(
            type="line",
            x0=0, y0=0, x1=max_val, y1=max_val,
            line=dict(color="red", width=2, dash="dash"),
            name="Threshold Line"
        )
        
        st.plotly_chart(fig_scatter, use_container_width=True)

def render_legal_entity_analysis(legal_entity_summary):
    """Render legal entity impact analysis"""
    
    st.subheader("🏢 Legal Entity Impact Analysis")
    
    if legal_entity_summary.empty:
        st.info("📊 No legal entity summary data available")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Alert volume by legal entity
        fig_volume = px.bar(
            legal_entity_summary,
            x='LegalEntity',
            y='TotalVol',
            title="Total Volume by Legal Entity",
            labels={'TotalVol': 'Total Volume', 'LegalEntity': 'Legal Entity'}
        )
        fig_volume.update_xaxes(tickangle=45)
        st.plotly_chart(fig_volume, use_container_width=True)
    
    with col2:
        # Alert comparison (Original vs Proposed vs Adjusted)
        if all(col in legal_entity_summary.columns for col in ['OrgAlerts', 'ProjAlerts', 'AdjustedAlerts']):
            
            fig_comparison = go.Figure()
            
            fig_comparison.add_trace(go.Bar(
                name='Original Alerts',
                x=legal_entity_summary['LegalEntity'],
                y=legal_entity_summary['OrgAlerts'],
                marker_color='lightcoral'
            ))
            
            fig_comparison.add_trace(go.Bar(
                name='Projected Alerts',
                x=legal_entity_summary['LegalEntity'],
                y=legal_entity_summary['ProjAlerts'],
                marker_color='lightskyblue'
            ))
            
            fig_comparison.add_trace(go.Bar(
                name='Adjusted Alerts',
                x=legal_entity_summary['LegalEntity'],
                y=legal_entity_summary['AdjustedAlerts'],
                marker_color='lightgreen'
            ))
            
            fig_comparison.update_layout(
                title='Alert Comparison by Threshold Type',
                xaxis_title='Legal Entity',
                yaxis_title='Number of Alerts',
                barmode='group'
            )
            
            fig_comparison.update_xaxes(tickangle=45)
            st.plotly_chart(fig_comparison, use_container_width=True)

def render_ops_workflow_analysis(ops_analysis):
    """Render ops workflow analysis"""
    
    st.subheader("📋 Ops Team Workflow Analysis")
    
    if ops_analysis.empty:
        st.info("📊 No ops workflow data available")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Reason code distribution
        if 'high_level_code' in ops_analysis.columns:
            reason_counts = ops_analysis['high_level_code'].value_counts()
            
            fig_pie = px.pie(
                values=reason_counts.values,
                names=reason_counts.index,
                title="Distribution of High-Level Reason Codes"
            )
            st.plotly_chart(fig_pie, use_container_width=True)
    
    with col2:
        # Processing time analysis (if available)
        if 'legal_entity' in ops_analysis.columns:
            entity_counts = ops_analysis.groupby('legal_entity').size().reset_index(name='processed_count')
            
            fig_bar = px.bar(
                entity_counts,
                x='legal_entity',
                y='processed_count',
                title="Processed Trades by Legal Entity",
                labels={'processed_count': 'Processed Count', 'legal_entity': 'Legal Entity'}
            )
            fig_bar.update_xaxes(tickangle=45)
            st.plotly_chart(fig_bar, use_container_width=True)
    
    # Detailed metrics table
    if 'high_level_code' in ops_analysis.columns:
        st.subheader("📊 Reason Code Metrics")
        
        reason_metrics = ops_analysis.groupby('high_level_code').agg({
            'trade_id': 'count',
            'deviationpercent': ['mean', 'max'],
            'threshold_used': 'mean'
        }).round(2)
        
        reason_metrics.columns = ['Count', 'Avg Deviation', 'Max Deviation', 'Avg Threshold']
        reason_metrics = reason_metrics.sort_values('Count', ascending=False)
        
        st.dataframe(reason_metrics, use_container_width=True)

def render_currency_analysis(alerts_df):
    """Render currency pair analysis"""
    
    st.subheader("💱 Currency Pair Analysis")
    
    if 'ccypair' not in alerts_df.columns:
        st.info("📊 No currency pair data available")
        return
    
    # Currency pair frequency
    ccypair_counts = alerts_df['ccypair'].value_counts().head(10)
    
    col1, col2 = st.columns(2)
    
    with col1:
        fig_ccypair = px.bar(
            x=ccypair_counts.index,
            y=ccypair_counts.values,
            title="Top 10 Currency Pairs by Alert Count",
            labels={'x': 'Currency Pair', 'y': 'Alert Count'}
        )
        fig_ccypair.update_xaxes(tickangle=45)
        st.plotly_chart(fig_ccypair, use_container_width=True)
    
    with col2:
        # Individual currency frequency
        currencies = []
        if 'ccy1' in alerts_df.columns and 'ccy2' in alerts_df.columns:
            currencies.extend(alerts_df['ccy1'].tolist())
            currencies.extend(alerts_df['ccy2'].tolist())
            
            currency_series = pd.Series(currencies)
            currency_counts = currency_series.value_counts().head(10)
            
            fig_currency = px.bar(
                x=currency_counts.index,
                y=currency_counts.values,
                title="Top 10 Individual Currencies by Alert Count",
                labels={'x': 'Currency', 'y': 'Alert Count'}
            )
            st.plotly_chart(fig_currency, use_container_width=True)
    
    # Currency pair deviation analysis
    if len(ccypair_counts) > 0:
        st.subheader("📈 Average Deviation by Currency Pair")
        
        ccypair_avg_deviation = alerts_df.groupby('ccypair')['deviationpercent'].agg(['mean', 'count']).round(2)
        ccypair_avg_deviation.columns = ['Avg Deviation %', 'Alert Count']
        ccypair_avg_deviation = ccypair_avg_deviation.sort_values('Alert Count', ascending=False).head(15)
        
        st.dataframe(ccypair_avg_deviation, use_container_width=True)

def render_quick_summary_bar(trade_data, alerts_df):
    """Render quick summary metrics bar"""
    total_trades = len(trade_data)
    total_alerts = len(alerts_df)
    alert_rate = (total_alerts / total_trades * 100) if total_trades > 0 else 0
    avg_deviation = alerts_df['deviationpercent'].mean() if not alerts_df.empty else 0
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Trades", f"{total_trades:,}")
    with col2:
        st.metric("Total Alerts", f"{total_alerts:,}")
    with col3:
        st.metric("Alert Rate", f"{alert_rate:.1f}%")
    with col4:
        st.metric("Avg Deviation", f"{avg_deviation:.2f}%")

def render_overview_tab(trade_data, alerts_df, legal_entity_summary, ops_analysis):
    """Render overview and analytics tab"""
    
    # Enhanced summary metrics
    render_summary_metrics(trade_data, alerts_df, ops_analysis)
    
    # Key visualizations in columns
    col1, col2 = st.columns(2)
    
    with col1:
        if not alerts_df.empty:
            # Alert distribution by legal entity
            entity_counts = alerts_df['legal_entity'].value_counts()
            fig = px.pie(
                values=entity_counts.values, 
                names=entity_counts.index,
                title="Alert Distribution by Legal Entity",
                color_discrete_sequence=px.colors.qualitative.Set3
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        if not alerts_df.empty:
            # Currency pair analysis
            currency_analysis = alerts_df.groupby('ccypair').agg({
                'deviationpercent': ['count', 'mean', 'max']
            }).round(2)
            currency_analysis.columns = ['Alert_Count', 'Avg_Deviation', 'Max_Deviation']
            currency_analysis = currency_analysis.reset_index().sort_values('Alert_Count', ascending=False)
            
            fig = px.bar(
                currency_analysis.head(10),
                x='ccypair',
                y='Alert_Count',
                title="Top 10 Currency Pairs by Alert Count",
                color='Avg_Deviation',
                color_continuous_scale='Reds'
            )
            fig.update_layout(height=400, xaxis_tickangle=-45)
            st.plotly_chart(fig, use_container_width=True)

def render_deviation_analysis_tab(alerts_df):
    """Render deviation analysis tab with enhanced pivoting"""
    
    if alerts_df.empty:
        st.info("No alert data available for deviation analysis")
        return
    
    st.subheader("🔍 Deviation Analysis")
    
    # Interactive pivot controls
    col1, col2, col3 = st.columns(3)
    
    with col1:
        pivot_rows = st.selectbox(
            "Group by (Rows)",
            options=['legal_entity', 'ccypair', 'product_type', 'source_system'],
            index=0,
            key="pivot_rows"
        )
    
    with col2:
        pivot_cols = st.selectbox(
            "Split by (Columns)", 
            options=[None, 'legal_entity', 'ccypair', 'product_type', 'source_system'],
            index=0,
            key="pivot_cols"
        )
    
    with col3:
        pivot_values = st.selectbox(
            "Measure",
            options=['count', 'mean_deviation', 'max_deviation', 'total_notional'],
            index=0,
            key="pivot_values"
        )
    
    # Create pivot table
    create_dynamic_pivot_table(alerts_df, pivot_rows, pivot_cols, pivot_values)
    
    # Deviation distribution histogram
    st.subheader("📊 Deviation Distribution")
    
    col1, col2 = st.columns(2)
    
    with col1:
        fig = px.histogram(
            alerts_df,
            x='deviationpercent',
            nbins=30,
            title="Distribution of Deviation Percentages",
            color_discrete_sequence=['#FF6B6B']
        )
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Box plot by legal entity
        fig = px.box(
            alerts_df,
            x='legal_entity',
            y='deviationpercent',
            title="Deviation Distribution by Legal Entity",
            color='legal_entity'
        )
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)

def render_legal_entity_tab(legal_entity_summary, alerts_df):
    """Render legal entity impact analysis tab"""
    
    st.subheader("🏢 Legal Entity Impact Analysis")
    
    # Enhanced legal entity metrics
    if not alerts_df.empty:
        entity_metrics = alerts_df.groupby('legal_entity').agg({
            'trade_id': 'count',
            'deviationpercent': ['mean', 'max', 'std'],
            'notional_amount': 'sum' if 'notional_amount' in alerts_df.columns else 'count'
        }).round(2)
        
        entity_metrics.columns = ['Total_Alerts', 'Avg_Deviation', 'Max_Deviation', 'Std_Deviation', 'Total_Notional']
        entity_metrics = entity_metrics.reset_index()
        
        # Interactive chart selection
        chart_type = st.radio(
            "Chart Type",
            options=['Bar Chart', 'Treemap', 'Scatter Plot'],
            horizontal=True,
            key="entity_chart_type"
        )
        
        if chart_type == 'Bar Chart':
            fig = px.bar(
                entity_metrics,
                x='legal_entity',
                y='Total_Alerts',
                color='Avg_Deviation',
                title="Alert Volume and Average Deviation by Legal Entity",
                color_continuous_scale='RdYlBu_r'
            )
        elif chart_type == 'Treemap':
            fig = px.treemap(
                entity_metrics,
                path=['legal_entity'],
                values='Total_Alerts',
                color='Avg_Deviation',
                title="Legal Entity Alert Distribution (Treemap)",
                color_continuous_scale='RdYlBu_r'
            )
        else:  # Scatter Plot
            fig = px.scatter(
                entity_metrics,
                x='Total_Alerts',
                y='Avg_Deviation',
                size='Max_Deviation',
                color='legal_entity',
                title="Alert Volume vs Average Deviation by Legal Entity",
                hover_data=['Std_Deviation']
            )
        
        fig.update_layout(height=500)
        st.plotly_chart(fig, use_container_width=True)
        
        # Data table
        st.subheader("📋 Detailed Metrics")
        st.dataframe(entity_metrics, use_container_width=True)
    else:
        st.info("No alert data available for legal entity analysis")

def render_ops_workflow_tab(ops_analysis, alerts_df):
    """Render ops workflow analysis tab"""
    
    st.subheader("⚙️ Operations Workflow Analysis")
    
    if ops_analysis.empty:
        st.info("No ops workflow data available. Upload exception data to see operational metrics.")
        return
    
    # Workflow metrics
    col1, col2, col3 = st.columns(3)
    
    total_processed = len(ops_analysis)
    total_alerts = len(alerts_df) if not alerts_df.empty else 0
    processing_rate = (total_processed / total_alerts * 100) if total_alerts > 0 else 0
    
    with col1:
        st.metric("Processed Alerts", f"{total_processed:,}")
    
    with col2:
        st.metric("Processing Rate", f"{processing_rate:.1f}%")
    
    with col3:
        avg_resolution_time = ops_analysis.get('processing_time', pd.Series()).mean() if 'processing_time' in ops_analysis.columns else 0
        st.metric("Avg Resolution Time", f"{avg_resolution_time:.1f}d" if avg_resolution_time > 0 else "N/A")
    
    # Reason code analysis
    if 'reasoncodeid' in ops_analysis.columns:
        st.subheader("📊 Reason Code Distribution")
        
        reason_counts = ops_analysis['reasoncodeid'].value_counts().head(10)
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.bar(
                x=reason_counts.index,
                y=reason_counts.values,
                title="Top 10 Reason Codes",
                labels={'x': 'Reason Code', 'y': 'Count'}
            )
            fig.update_layout(height=400, xaxis_tickangle=-45)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            fig = px.pie(
                values=reason_counts.values,
                names=reason_counts.index,
                title="Reason Code Distribution",
                color_discrete_sequence=px.colors.qualitative.Pastel
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)

def create_dynamic_pivot_table(alerts_df, pivot_rows, pivot_cols, pivot_values):
    """Create dynamic pivot table based on user selections"""
    
    try:
        # Prepare aggregation based on selected values
        if pivot_values == 'count':
            agg_func = 'count'
            value_col = 'trade_id'
            title_suffix = "Count"
        elif pivot_values == 'mean_deviation':
            agg_func = 'mean'
            value_col = 'deviationpercent'
            title_suffix = "Average Deviation %"
        elif pivot_values == 'max_deviation':
            agg_func = 'max'
            value_col = 'deviationpercent'
            title_suffix = "Maximum Deviation %"
        else:  # total_notional
            agg_func = 'sum'
            value_col = 'notional_amount' if 'notional_amount' in alerts_df.columns else 'trade_id'
            title_suffix = "Total Notional" if 'notional_amount' in alerts_df.columns else "Count"
        
        # Create pivot table
        if pivot_cols and pivot_cols != 'None':
            pivot_table = alerts_df.pivot_table(
                values=value_col,
                index=pivot_rows,
                columns=pivot_cols,
                aggfunc=agg_func,
                fill_value=0
            ).round(2)
        else:
            pivot_table = alerts_df.groupby(pivot_rows)[value_col].agg(agg_func).round(2)
        
        st.subheader(f"📊 Pivot Analysis: {title_suffix}")
        
        # Display pivot table
        if isinstance(pivot_table, pd.DataFrame) and len(pivot_table.columns) > 1:
            st.dataframe(pivot_table, use_container_width=True)
            
            # Heatmap for pivot table
            if len(pivot_table) > 1 and len(pivot_table.columns) > 1:
                fig = px.imshow(
                    pivot_table.values,
                    x=pivot_table.columns,
                    y=pivot_table.index,
                    color_continuous_scale='RdYlBu_r',
                    title=f"Heatmap: {title_suffix} by {pivot_rows} vs {pivot_cols}"
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
        else:
            # Simple series display
            if isinstance(pivot_table, pd.Series):
                pivot_df = pivot_table.reset_index()
                pivot_df.columns = [pivot_rows, title_suffix]
                st.dataframe(pivot_df, use_container_width=True)
                
                # Bar chart for series
                fig = px.bar(
                    pivot_df,
                    x=pivot_rows,
                    y=title_suffix,
                    title=f"{title_suffix} by {pivot_rows}"
                )
                fig.update_layout(height=400)
                st.plotly_chart(fig, use_container_width=True)
    
    except Exception as e:
        st.error(f"Error creating pivot table: {str(e)}")
        st.info("Please try different pivot configurations")
