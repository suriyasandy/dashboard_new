import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode, DataReturnMode
from utils.helpers import create_download_button, filter_alerts_by_bucket, format_number, format_percentage

def render_data_tables():
    """Render interactive data tables with AgGrid"""
    
    # Get data from session state
    threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
    alerts_df = st.session_state.get('alerts_df', pd.DataFrame())
    groupwise_summary = st.session_state.get('groupwise_summary', pd.DataFrame())
    expanded_summary = st.session_state.get('expanded_summary', pd.DataFrame())
    legal_entity_summary = st.session_state.get('legal_entity_summary', pd.DataFrame())
    ops_analysis = st.session_state.get('ops_analysis', pd.DataFrame())
    
    if threshold_df.empty:
        st.info("📊 Upload threshold file to view data tables")
        return
    
    # Create tabs for different tables
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "🎯 Thresholds", 
        "📊 Groupwise Summary", 
        "🔍 Expanded Summary",
        "🏢 Legal Entity Impact",
        "📋 Ops Analysis",
        "🚨 Alert Details"
    ])
    
    with tab1:
        render_threshold_table(threshold_df)
    
    with tab2:
        render_groupwise_summary_table(groupwise_summary, alerts_df)
    
    with tab3:
        render_expanded_summary_table(expanded_summary, alerts_df)
    
    with tab4:
        render_legal_entity_table(legal_entity_summary)
    
    with tab5:
        render_ops_analysis_table(ops_analysis)
    
    with tab6:
        render_alert_details_table(alerts_df)

def render_threshold_table(threshold_df):
    """Render editable threshold configuration table"""
    
    st.subheader("🎯 Threshold Configuration")
    
    if threshold_df.empty:
        st.info("No threshold data available")
        return
    
    # Make copy for editing
    editable_df = threshold_df.copy()
    
    # Configure AgGrid
    gb = GridOptionsBuilder.from_dataframe(editable_df)
    gb.configure_pagination(paginationAutoPageSize=True)
    gb.configure_side_bar()
    gb.configure_default_column(groupable=True, value=True, enableRowGroup=True, editable=False)
    
    # Make adjusted columns editable
    gb.configure_column("Adjusted_Group", editable=True)
    gb.configure_column("Adjusted_Threshold", editable=True, type=["numericColumn"])
    
    # Highlight adjusted columns
    gb.configure_column("Adjusted_Group", cellStyle={'backgroundColor': '#e3f2fd'})
    gb.configure_column("Adjusted_Threshold", cellStyle={'backgroundColor': '#e3f2fd'})
    
    gb.configure_selection('multiple', use_checkbox=True)
    grid_options = gb.build()
    
    # Display grid
    grid_response = AgGrid(
        editable_df,
        gridOptions=grid_options,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.MODEL_CHANGED,
        fit_columns_on_grid_load=True,
        enable_enterprise_modules=False,
        height=400,
        key="threshold_grid"
    )
    
    # Handle updates
    if grid_response['data'].equals(editable_df) == False:
        st.session_state.threshold_df = grid_response['data']
        st.success("✅ Threshold values updated")
        st.rerun()
    
    # Download button
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        create_download_button(
            grid_response['data'], 
            "thresholds", 
            "📥 Download Thresholds",
            key="download_thresholds"
        )

def render_groupwise_summary_table(groupwise_summary, alerts_df):
    """Render groupwise deviation bucket summary with drill-down"""
    
    st.subheader("📊 Groupwise Deviation Bucket Summary")
    
    if groupwise_summary.empty:
        st.info("No groupwise summary data available")
        return
    
    # Prepare display dataframe
    display_df = groupwise_summary.copy()
    
    # Configure AgGrid
    gb = GridOptionsBuilder.from_dataframe(display_df)
    gb.configure_pagination(paginationAutoPageSize=True)
    gb.configure_side_bar()
    gb.configure_default_column(groupable=True, value=True, enableRowGroup=True)
    
    # Highlight rows above max threshold
    if 'highlight' in display_df.columns:
        gb.configure_column("highlight", hide=True)
        
        # Apply conditional formatting
        def highlight_row(params):
            if params.data and params.data.get('highlight', False):
                return {'backgroundColor': '#ffebee', 'color': '#c62828'}
            return {}
        
        gb.configure_grid_options(getRowStyle=highlight_row)
    
    gb.configure_selection('single', use_checkbox=False)
    grid_options = gb.build()
    
    # Display grid
    grid_response = AgGrid(
        display_df,
        gridOptions=grid_options,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.SELECTION_CHANGED,
        fit_columns_on_grid_load=True,
        height=400,
        key="groupwise_summary_grid"
    )
    
    # Handle row selection for drill-down
    selected_rows = grid_response['selected_rows']
    
    if selected_rows:
        selected_bucket = selected_rows[0]['Deviation_Bucket']
        st.session_state.selected_bucket = selected_bucket
        
        # Show drill-down details
        render_bucket_drill_down(selected_bucket, alerts_df)
    
    # Download button
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        create_download_button(
            display_df.drop('highlight', axis=1, errors='ignore'), 
            "groupwise_summary", 
            "📥 Download Summary",
            key="download_groupwise"
        )

def render_expanded_summary_table(expanded_summary, alerts_df):
    """Render expanded bucket summary"""
    
    st.subheader("🔍 Expanded Bucket Summary")
    
    if expanded_summary.empty:
        st.info("No expanded summary data available")
        return
    
    # Prepare display dataframe
    display_df = expanded_summary.copy()
    
    # Configure AgGrid
    gb = GridOptionsBuilder.from_dataframe(display_df)
    gb.configure_pagination(paginationAutoPageSize=True)
    gb.configure_side_bar()
    gb.configure_default_column(groupable=True, value=True, enableRowGroup=True)
    
    # Highlight all rows (above max threshold)
    if 'highlight' in display_df.columns:
        gb.configure_column("highlight", hide=True)
        gb.configure_grid_options(
            getRowStyle={'backgroundColor': '#fff3e0', 'color': '#ef6c00'}
        )
    
    gb.configure_selection('single', use_checkbox=False)
    grid_options = gb.build()
    
    # Display grid
    grid_response = AgGrid(
        display_df,
        gridOptions=grid_options,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.SELECTION_CHANGED,
        fit_columns_on_grid_load=True,
        height=400,
        key="expanded_summary_grid"
    )
    
    # Handle row selection for drill-down
    selected_rows = grid_response['selected_rows']
    
    if selected_rows:
        selected_bucket = selected_rows[0]['Deviation_Bucket']
        render_bucket_drill_down(selected_bucket, alerts_df)
    
    # Download button
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        create_download_button(
            display_df.drop('highlight', axis=1, errors='ignore'), 
            "expanded_summary", 
            "📥 Download Summary",
            key="download_expanded"
        )

def render_legal_entity_table(legal_entity_summary):
    """Render legal entity impact summary"""
    
    st.subheader("🏢 Legal Entity Impact Analysis")
    
    if legal_entity_summary.empty:
        st.info("No legal entity summary data available")
        return
    
    # Configure AgGrid
    gb = GridOptionsBuilder.from_dataframe(legal_entity_summary)
    gb.configure_pagination(paginationAutoPageSize=True)
    gb.configure_side_bar()
    gb.configure_default_column(groupable=True, value=True, enableRowGroup=True)
    
    # Format numeric columns
    numeric_columns = ['TotalVol', 'OrgAlerts', 'ProjAlerts', 'AdjustedAlerts']
    for col in numeric_columns:
        if col in legal_entity_summary.columns:
            gb.configure_column(col, type=["numericColumn"], precision=0)
    
    gb.configure_selection('multiple', use_checkbox=True)
    grid_options = gb.build()
    
    # Display grid
    grid_response = AgGrid(
        legal_entity_summary,
        gridOptions=grid_options,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.SELECTION_CHANGED,
        fit_columns_on_grid_load=True,
        height=400,
        key="legal_entity_grid"
    )
    
    # Show selection summary
    selected_data = grid_response['selected_rows']
    if selected_data:
        st.info(f"📊 Selected {len(selected_data)} legal entities")
    
    # Download button
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        create_download_button(
            legal_entity_summary, 
            "legal_entity_summary", 
            "📥 Download Summary",
            key="download_legal_entity"
        )

def render_ops_analysis_table(ops_analysis):
    """Render ops team workflow analysis"""
    
    st.subheader("📋 Ops Team Workflow Analysis")
    
    if ops_analysis.empty:
        st.info("No ops analysis data available")
        return
    
    # Configure AgGrid
    gb = GridOptionsBuilder.from_dataframe(ops_analysis)
    gb.configure_pagination(paginationAutoPageSize=True)
    gb.configure_side_bar()
    gb.configure_default_column(groupable=True, value=True, enableRowGroup=True)
    
    # Format numeric columns
    gb.configure_column("deviationpercent", type=["numericColumn"], precision=2)
    gb.configure_column("threshold_used", type=["numericColumn"], precision=2)
    
    # Color code by high level code
    if 'high_level_code' in ops_analysis.columns:
        gb.configure_column("high_level_code", cellStyle={'fontWeight': 'bold'})
    
    gb.configure_selection('multiple', use_checkbox=True)
    grid_options = gb.build()
    
    # Display grid
    grid_response = AgGrid(
        ops_analysis,
        gridOptions=grid_options,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.SELECTION_CHANGED,
        fit_columns_on_grid_load=True,
        height=400,
        key="ops_analysis_grid"
    )
    
    # Show summary statistics
    if not ops_analysis.empty:
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Processed", len(ops_analysis))
        
        with col2:
            if 'high_level_code' in ops_analysis.columns:
                unique_codes = ops_analysis['high_level_code'].nunique()
                st.metric("Unique Reason Codes", unique_codes)
        
        with col3:
            avg_deviation = ops_analysis['deviationpercent'].mean()
            st.metric("Avg Deviation", f"{avg_deviation:.2f}%")
        
        with col4:
            if 'legal_entity' in ops_analysis.columns:
                unique_entities = ops_analysis['legal_entity'].nunique()
                st.metric("Legal Entities", unique_entities)
    
    # Download button
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        create_download_button(
            ops_analysis, 
            "ops_analysis", 
            "📥 Download Analysis",
            key="download_ops_analysis"
        )

def render_alert_details_table(alerts_df):
    """Render detailed alert information"""
    
    st.subheader("🚨 Alert Details")
    
    if alerts_df.empty:
        st.info("No alert data available")
        return
    
    # Show filtered alerts if bucket is selected
    filtered_alerts = alerts_df
    if st.session_state.get('selected_bucket'):
        filtered_alerts = filter_alerts_by_bucket(alerts_df, st.session_state.selected_bucket)
        st.info(f"📊 Showing alerts for bucket: {st.session_state.selected_bucket}")
    
    if filtered_alerts.empty:
        st.warning("No alerts found for selected bucket")
        return
    
    # Configure AgGrid
    gb = GridOptionsBuilder.from_dataframe(filtered_alerts)
    gb.configure_pagination(paginationAutoPageSize=True)
    gb.configure_side_bar()
    gb.configure_default_column(groupable=True, value=True, enableRowGroup=True)
    
    # Format specific columns
    gb.configure_column("deviationpercent", type=["numericColumn"], precision=2)
    gb.configure_column("threshold_used", type=["numericColumn"], precision=2)
    
    # Highlight high deviation alerts
    gb.configure_column("deviationpercent", 
                       cellStyle={
                           'color': 'red',
                           'fontWeight': 'bold'
                       })
    
    gb.configure_selection('multiple', use_checkbox=True)
    grid_options = gb.build()
    
    # Display grid
    grid_response = AgGrid(
        filtered_alerts,
        gridOptions=grid_options,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.SELECTION_CHANGED,
        fit_columns_on_grid_load=True,
        height=500,
        key="alert_details_grid"
    )
    
    # Show selection summary
    selected_data = grid_response['selected_rows']
    if selected_data:
        st.info(f"📊 Selected {len(selected_data)} alerts")
        
        # Show quick stats for selected alerts
        selected_df = pd.DataFrame(selected_data)
        if not selected_df.empty:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                avg_dev = selected_df['deviationpercent'].mean()
                st.metric("Avg Deviation", f"{avg_dev:.2f}%")
            
            with col2:
                max_dev = selected_df['deviationpercent'].max()
                st.metric("Max Deviation", f"{max_dev:.2f}%")
            
            with col3:
                unique_pairs = selected_df['ccypair'].nunique() if 'ccypair' in selected_df.columns else 0
                st.metric("Unique Pairs", unique_pairs)
    
    # Download buttons
    col1, col2, col3 = st.columns([1, 1, 2])
    
    with col1:
        create_download_button(
            filtered_alerts, 
            "alert_details", 
            "📥 Download All Alerts",
            key="download_all_alerts"
        )
    
    with col2:
        if selected_data:
            create_download_button(
                pd.DataFrame(selected_data), 
                "selected_alerts", 
                "📥 Download Selected",
                key="download_selected_alerts"
            )

def render_bucket_drill_down(bucket_label, alerts_df):
    """Render drill-down view for selected bucket"""
    
    st.subheader(f"🔍 Drill-Down: {bucket_label}")
    
    # Filter alerts for the selected bucket
    filtered_alerts = filter_alerts_by_bucket(alerts_df, bucket_label)
    
    if filtered_alerts.empty:
        st.warning("No alerts found in selected bucket")
        return
    
    # Show summary metrics for the bucket
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Alerts in Bucket", len(filtered_alerts))
    
    with col2:
        avg_dev = filtered_alerts['deviationpercent'].mean()
        st.metric("Avg Deviation", f"{avg_dev:.2f}%")
    
    with col3:
        unique_pairs = filtered_alerts['ccypair'].nunique() if 'ccypair' in filtered_alerts.columns else 0
        st.metric("Unique Currency Pairs", unique_pairs)
    
    with col4:
        unique_entities = filtered_alerts['legal_entity'].nunique() if 'legal_entity' in filtered_alerts.columns else 0
        st.metric("Legal Entities", unique_entities)
    
    # Show top currency pairs in this bucket
    if 'ccypair' in filtered_alerts.columns:
        st.subheader("🔝 Top Currency Pairs in Bucket")
        ccypair_counts = filtered_alerts['ccypair'].value_counts().head(10)
        
        if not ccypair_counts.empty:
            ccypair_df = pd.DataFrame({
                'Currency Pair': ccypair_counts.index,
                'Alert Count': ccypair_counts.values
            })
            st.dataframe(ccypair_df, use_container_width=True)
    
    # Download button for bucket data
    create_download_button(
        filtered_alerts, 
        f"bucket_{bucket_label.replace(' - ', '_to_')}", 
        f"📥 Download Bucket Data",
        key=f"download_bucket_{bucket_label}"
    )
