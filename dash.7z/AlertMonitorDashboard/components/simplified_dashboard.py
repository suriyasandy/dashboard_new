import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from utils.helpers import format_number, format_percentage

def render_simplified_dashboard():
    """Render simplified dashboard according to detailed requirements"""
    
    st.title("🔍 GFX Threshold Deviation Dashboard")
    st.caption("Ops Team - Comprehensive Trade Alert Analysis with Configurable Thresholds")
    
    # Get data from session state
    trade_data = st.session_state.get('trade_data', pd.DataFrame())
    threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
    threshold_mode = st.session_state.get('threshold_mode', 'group')
    
    if trade_data.empty or threshold_df.empty:
        st.info("📊 Upload trade data and threshold configuration to begin analysis")
        return
    
    # ROW 1: Threshold Management and Impact Analysis
    render_row1_threshold_and_impact(threshold_df, threshold_mode)
    
    # ROW 2: Reason Code Analysis (if impact analysis completed)
    if st.session_state.get('impact_analysis_completed', False):
        render_row2_reason_code_analysis()
    
    # ROW 3: Deviation Bucket Analysis
    if st.session_state.get('impact_analysis_completed', False):
        render_row3_deviation_buckets()

def render_row1_threshold_and_impact(threshold_df, threshold_mode):
    """Render Row 1: Threshold table and Impact Analysis"""
    
    st.subheader("📊 Row 1: Threshold Configuration & Impact Analysis")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("🔧 Threshold Configuration")
        render_threshold_table(threshold_df, threshold_mode)
    
    with col2:
        st.subheader("📈 Impact Analysis Results")
        render_impact_analysis_results()

def render_threshold_table(threshold_df, threshold_mode):
    """Render editable threshold table based on mode"""
    
    if threshold_mode == 'group':
        # Group-wise threshold table
        st.write("**Group-wise Thresholds**")
        
        # Create simplified group table
        if 'group' in threshold_df.columns:
            group_summary = threshold_df.groupby('group').agg({
                'original_threshold': 'first',
                'proposed_threshold': 'first',
                'adjusted_threshold': 'first'
            }).reset_index()
            
            # Display editable table
            edited_data = st.data_editor(
                group_summary,
                column_config={
                    "group": st.column_config.TextColumn("Group", disabled=True),
                    "original_threshold": st.column_config.NumberColumn("Orig Thresh", disabled=True, format="%.2f"),
                    "proposed_threshold": st.column_config.NumberColumn("Prop Thresh", disabled=True, format="%.2f"),
                    "adjusted_threshold": st.column_config.NumberColumn("Adj Thresh", format="%.2f")
                },
                use_container_width=True,
                key="group_threshold_editor"
            )
            
            # Update and Reset buttons
            col_a, col_b = st.columns(2)
            with col_a:
                if st.button("🔄 Update Thresholds", key="update_group_thresh"):
                    update_group_thresholds(edited_data)
                    st.success("Group thresholds updated!")
            
            with col_b:
                if st.button("↩️ Reset to Proposed", key="reset_group_thresh"):
                    reset_group_thresholds()
                    st.success("Thresholds reset to proposed values!")
    
    else:  # currency-wise
        st.write("**Currency-wise Thresholds**")
        
        # Display currency-wise table
        currency_columns = ['legal_entity', 'ccy', 'original_group', 'original_threshold', 
                          'proposed_group', 'proposed_threshold', 'adjusted_group', 'adjusted_threshold']
        
        if all(col in threshold_df.columns for col in ['legal_entity', 'ccy']):
            edited_data = st.data_editor(
                threshold_df[currency_columns] if all(col in threshold_df.columns for col in currency_columns) else threshold_df,
                column_config={
                    "legal_entity": st.column_config.TextColumn("Legal Entity", disabled=True),
                    "ccy": st.column_config.TextColumn("CCY", disabled=True),
                    "original_group": st.column_config.TextColumn("Orig Group", disabled=True),
                    "original_threshold": st.column_config.NumberColumn("Orig Thresh", disabled=True, format="%.2f"),
                    "proposed_group": st.column_config.TextColumn("Prop Group", disabled=True),
                    "proposed_threshold": st.column_config.NumberColumn("Prop Thresh", disabled=True, format="%.2f"),
                    "adjusted_group": st.column_config.TextColumn("Adj Group"),
                    "adjusted_threshold": st.column_config.NumberColumn("Adj Thresh", format="%.2f")
                },
                use_container_width=True,
                key="currency_threshold_editor"
            )
            
            # Update and Reset buttons
            col_a, col_b = st.columns(2)
            with col_a:
                if st.button("🔄 Update Thresholds", key="update_currency_thresh"):
                    update_currency_thresholds(edited_data)
                    st.success("Currency thresholds updated!")
            
            with col_b:
                if st.button("↩️ Reset to Proposed", key="reset_currency_thresh"):
                    reset_currency_thresholds()
                    st.success("Thresholds reset to proposed values!")
    
    # Run Impact Analysis Button
    st.markdown("---")
    if st.button("🚀 Run Impact Analysis", type="primary", use_container_width=True):
        run_impact_analysis()

def render_impact_analysis_results():
    """Render impact analysis results with selectable functionality"""
    
    legal_entity_summary = st.session_state.get('legal_entity_summary', pd.DataFrame())
    
    if legal_entity_summary.empty:
        st.info("Run impact analysis to see results")
        return
    
    st.write("**Legal Entity Impact Summary**")
    
    # Display selectable impact summary
    if not legal_entity_summary.empty:
        # Format the summary table
        display_cols = ['LegalEntity', 'SourceSystem', 'TotalVol', 'OrgAlerts', 'ProjAlerts', 'AdjAlerts']
        available_cols = [col for col in display_cols if col in legal_entity_summary.columns]
        
        selected_record = st.dataframe(
            legal_entity_summary[available_cols],
            use_container_width=True,
            on_select="rerun",
            selection_mode="single-row",
            key="impact_summary_selector"
        )
        
        # Store selected record for Row 2 analysis
        if selected_record and len(selected_record.selection.rows) > 0:
            selected_idx = selected_record.selection.rows[0]
            st.session_state.selected_entity_record = legal_entity_summary.iloc[selected_idx]
            st.session_state.entity_selected = True
            
            # Show selected record info
            selected_entity = st.session_state.selected_entity_record
            st.success(f"Selected: {selected_entity.get('LegalEntity', 'N/A')} - {selected_entity.get('SourceSystem', 'N/A')}")

def render_row2_reason_code_analysis():
    """Render Row 2: Reason Code Mapping and Analysis"""
    
    st.markdown("---")
    st.subheader("📋 Row 2: Reason Code Analysis")
    
    if not st.session_state.get('entity_selected', False):
        st.info("Select a record from Impact Analysis to view reason code breakdown")
        return
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("🏷️ High-Level Code Summary")
        render_high_level_code_summary()
    
    with col2:
        st.subheader("🔍 Detailed Reason Code Breakdown")
        render_detailed_reason_breakdown()

def render_high_level_code_summary():
    """Render high-level code summary with selection"""
    
    ops_analysis = st.session_state.get('ops_analysis', pd.DataFrame())
    
    if ops_analysis.empty:
        st.info("No reason code data available")
        return
    
    # Create high-level code summary
    if 'high_level_code' in ops_analysis.columns:
        high_level_summary = ops_analysis.groupby(['high_level_code', 'business_date']).size().reset_index(name='alert_count')
        
        selected_hl_code = st.dataframe(
            high_level_summary,
            use_container_width=True,
            on_select="rerun",
            selection_mode="single-row",
            key="high_level_code_selector"
        )
        
        # Store selected high-level code
        if selected_hl_code and len(selected_hl_code.selection.rows) > 0:
            selected_idx = selected_hl_code.selection.rows[0]
            st.session_state.selected_hl_code = high_level_summary.iloc[selected_idx]
            st.session_state.hl_code_selected = True

def render_detailed_reason_breakdown():
    """Render detailed reason code breakdown"""
    
    if not st.session_state.get('hl_code_selected', False):
        st.info("Select a high-level code to view detailed breakdown")
        return
    
    ops_analysis = st.session_state.get('ops_analysis', pd.DataFrame())
    selected_hl_code = st.session_state.get('selected_hl_code', {})
    
    if ops_analysis.empty:
        return
    
    # Filter ops analysis for selected high-level code
    hl_code = selected_hl_code.get('high_level_code')
    business_date = selected_hl_code.get('business_date')
    
    filtered_ops = ops_analysis[
        (ops_analysis['high_level_code'] == hl_code) & 
        (ops_analysis['business_date'] == business_date)
    ]
    
    if not filtered_ops.empty:
        # Create detailed breakdown
        detailed_breakdown = filtered_ops.groupby(['reasoncodeid', 'business_date']).size().reset_index(name='alert_count')
        
        st.dataframe(
            detailed_breakdown,
            use_container_width=True,
            key="detailed_reason_breakdown"
        )
        
        # Download option
        st.download_button(
            label="📥 Download Detailed Breakdown",
            data=detailed_breakdown.to_csv(index=False),
            file_name=f"reason_breakdown_{hl_code}_{business_date}.csv",
            mime="text/csv"
        )

def render_row3_deviation_buckets():
    """Render Row 3: Deviation Bucket Analysis"""
    
    st.markdown("---")
    st.subheader("📊 Row 3: Deviation Bucket Distribution")
    
    alerts_df = st.session_state.get('alerts_df', pd.DataFrame())
    threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
    
    if alerts_df.empty:
        st.info("No alert data available for bucket analysis")
        return
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("📈 Groupwise Bucket Summary")
        render_groupwise_bucket_summary(alerts_df, threshold_df)
    
    with col2:
        st.subheader("📊 Expanded Bucket Summary")
        render_expanded_bucket_summary(alerts_df, threshold_df)

def render_groupwise_bucket_summary(alerts_df, threshold_df):
    """Render groupwise bucket summary with pivot functionality"""
    
    from services.deviation_analyzer import DeviationAnalyzer
    analyzer = DeviationAnalyzer()
    
    try:
        # Create groupwise summary using proposed thresholds
        groupwise_summary = analyzer.create_groupwise_summary(alerts_df, threshold_df)
        
        if not groupwise_summary.empty:
            # Display pivot table
            st.dataframe(
                groupwise_summary,
                use_container_width=True,
                key="groupwise_summary_table"
            )
            
            # Interactive pivot controls
            st.subheader("🔄 Pivot Analysis")
            
            pivot_by = st.selectbox(
                "Pivot by:",
                options=['currency', 'legal_entity', 'source_system'],
                key="groupwise_pivot_by"
            )
            
            if pivot_by and pivot_by in alerts_df.columns:
                pivot_summary = alerts_df.groupby([pivot_by, 'deviation_bucket']).size().unstack(fill_value=0)
                
                if not pivot_summary.empty:
                    st.dataframe(pivot_summary, use_container_width=True)
                    
                    # Visualization
                    fig = px.bar(
                        pivot_summary.reset_index(),
                        x=pivot_by,
                        y=pivot_summary.columns.tolist(),
                        title=f"Alert Distribution by {pivot_by} and Deviation Bucket"
                    )
                    st.plotly_chart(fig, use_container_width=True)
            
            # Download option
            st.download_button(
                label="📥 Download Groupwise Summary",
                data=groupwise_summary.to_csv(index=False),
                file_name="groupwise_bucket_summary.csv",
                mime="text/csv"
            )
    
    except Exception as e:
        st.error(f"Error creating groupwise summary: {str(e)}")

def render_expanded_bucket_summary(alerts_df, threshold_df):
    """Render expanded bucket summary for high deviations"""
    
    from services.deviation_analyzer import DeviationAnalyzer
    analyzer = DeviationAnalyzer()
    
    try:
        # Get max proposed threshold
        max_threshold = threshold_df['proposed_threshold'].max() if 'proposed_threshold' in threshold_df.columns else 2.0
        
        # Filter alerts above max threshold
        high_deviation_alerts = alerts_df[alerts_df['deviationpercent'] > max_threshold]
        
        if not high_deviation_alerts.empty:
            # Create expanded summary
            expanded_summary = analyzer.create_expanded_summary(high_deviation_alerts, threshold_df, bin_size=0.5)
            
            st.dataframe(
                expanded_summary,
                use_container_width=True,
                key="expanded_summary_table"
            )
            
            # Visualization
            if not expanded_summary.empty and 'bucket_label' in expanded_summary.columns:
                fig = px.bar(
                    expanded_summary,
                    x='bucket_label',
                    y='count',
                    title="High Deviation Alert Distribution (Expanded Buckets)",
                    color='count',
                    color_continuous_scale='Reds'
                )
                fig.update_layout(xaxis_tickangle=-45)
                st.plotly_chart(fig, use_container_width=True)
            
            # Download option
            st.download_button(
                label="📥 Download Expanded Summary",
                data=expanded_summary.to_csv(index=False),
                file_name="expanded_bucket_summary.csv",
                mime="text/csv"
            )
        else:
            st.info("No alerts exceed the maximum proposed threshold")
    
    except Exception as e:
        st.error(f"Error creating expanded summary: {str(e)}")

def update_group_thresholds(edited_data):
    """Update group thresholds in session state"""
    threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
    
    for _, row in edited_data.iterrows():
        group = row['group']
        new_threshold = row['adjusted_threshold']
        threshold_df.loc[threshold_df['group'] == group, 'adjusted_threshold'] = new_threshold
    
    st.session_state.threshold_df = threshold_df

def reset_group_thresholds():
    """Reset group thresholds to proposed values"""
    threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
    
    if 'proposed_threshold' in threshold_df.columns:
        threshold_df['adjusted_threshold'] = threshold_df['proposed_threshold']
        st.session_state.threshold_df = threshold_df

def update_currency_thresholds(edited_data):
    """Update currency thresholds in session state"""
    st.session_state.threshold_df = edited_data

def reset_currency_thresholds():
    """Reset currency thresholds to proposed values"""
    threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
    
    if 'proposed_threshold' in threshold_df.columns and 'proposed_group' in threshold_df.columns:
        threshold_df['adjusted_threshold'] = threshold_df['proposed_threshold']
        threshold_df['adjusted_group'] = threshold_df['proposed_group']
        st.session_state.threshold_df = threshold_df

def run_impact_analysis():
    """Run comprehensive impact analysis"""
    
    try:
        # Get data from session state
        trade_data = st.session_state.get('trade_data', pd.DataFrame())
        threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
        exception_data = st.session_state.get('exception_data', pd.DataFrame())
        
        # Run deviation analysis
        from services.deviation_analyzer import DeviationAnalyzer
        from services.reason_code_mapper import ReasonCodeMapper
        
        analyzer = DeviationAnalyzer()
        
        # Apply thresholds and identify alerts
        alerts_df = analyzer.apply_thresholds(trade_data, threshold_df)
        
        # Create legal entity summary
        legal_entity_summary = analyzer.create_legal_entity_summary(alerts_df, threshold_df)
        
        # Store results in session state
        st.session_state.alerts_df = alerts_df
        st.session_state.legal_entity_summary = legal_entity_summary
        st.session_state.impact_analysis_completed = True
        
        # Run reason code analysis if exception data available
        if not exception_data.empty:
            reason_code_mapper = ReasonCodeMapper()
            reason_code_mapping = st.session_state.get('reason_code_mapping', pd.DataFrame())
            
            ops_analysis = reason_code_mapper.analyze_ops_workflow(
                alerts_df, exception_data, reason_code_mapping
            )
            st.session_state.ops_analysis = ops_analysis
        
        st.success("Impact analysis completed successfully!")
        st.rerun()
    
    except Exception as e:
        st.error(f"Error running impact analysis: {str(e)}")