import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta
import os
import threading
from concurrent.futures import ThreadPoolExecutor
import io

from services.api_client import APIClient
from services.data_processor import DataProcessor
from services.threshold_manager import ThresholdManager
from services.deviation_analyzer import DeviationAnalyzer
from services.reason_code_mapper import ReasonCodeMapper
from services.file_data_loader import FileDataLoader
from components.sidebar import render_sidebar
from components.dashboard import render_dashboard
from components.simplified_dashboard import render_simplified_dashboard
from components.data_tables import render_data_tables
from utils.helpers import initialize_session_state, export_dataframe
from utils.enhanced_sample_loader import EnhancedSampleLoader

# Configure page
st.set_page_config(
    page_title="GFX Threshold Deviation Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

def main():
    """Main application entry point"""
    
    # Initialize session state
    initialize_session_state()
    
    # Title and description
    st.title("🔍 GFX Threshold Deviation Dashboard")
    st.markdown("**Ops Team** - Trade Alert Analysis with Configurable Thresholds and Reason Code Workflow")
    
    # Render sidebar controls
    sidebar_data = render_sidebar()
    
    # Main content area
    if sidebar_data.get('data_loaded', False):
        # Process data based on sidebar selections
        process_dashboard_data(sidebar_data)
        
        # Render dashboard based on selected mode
        dashboard_mode = st.session_state.get('dashboard_mode', 'Simplified Dashboard')
        
        if dashboard_mode == "Simplified Dashboard":
            render_simplified_dashboard()
        else:
            # Advanced dashboard with tabs
            tab1, tab2 = st.tabs(["📊 Dashboard", "📋 Data Tables"])
            
            with tab1:
                render_dashboard()
            
            with tab2:
                render_data_tables()
    else:
        # Show instructions when no data is loaded
        st.info("👈 Please configure the parameters in the sidebar and load data to begin analysis.")
        
        # Show instructions and sample file formats
        with st.expander("📄 Sample Data Files"):
            st.markdown("### Download Sample Files for Testing")
            st.markdown("""
            The dashboard supports two data source modes:
            
            **1. API Mode**: Connects to external APIs (requires credentials)
            **2. Manual Upload Mode**: Upload CSV files directly
            
            For testing, use Manual Upload mode with these sample files:
            """)
            
            # File download links
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Trade Data Files (9 files):**")
                st.markdown("- FX_SPOT_Entity1_SYSTEM_A.csv")
                st.markdown("- FX_FORWARD_Entity1_SYSTEM_A.csv") 
                st.markdown("- FX_SWAP_Entity1_SYSTEM_A.csv")
                st.markdown("- And 6 more files for Entity2 & Entity3...")
                
            with col2:
                st.markdown("**Configuration Files:**")
                st.markdown("- threshold_config_sample.csv")
                st.markdown("- reason_codes_sample.csv")
                st.markdown("- exception_data_sample.csv")
        
        with st.expander("📄 Threshold File Format"):
            sample_df = pd.DataFrame({
                'LegalEntity': ['Entity1', 'Entity2', 'ALL'],
                'CCY': ['USD', 'EUR', 'GBP'],
                'Original_Group': ['Group1', 'Group2', 'Group1'],
                'Original_Threshold': [0.5, 0.75, 1.0],
                'Proposed_Group': ['Group1', 'Group1', 'Group1'],
                'Proposed_Threshold': [0.3, 0.5, 0.8]
            })
            st.dataframe(sample_df)
            st.markdown("**Note:** Adjusted_Group and Adjusted_Threshold columns will be added automatically and are editable in the dashboard.")

def process_dashboard_data(sidebar_data):
    """Process and analyze data based on sidebar selections"""
    
    with st.spinner("Processing trade and exception data..."):
        try:
            # Initialize services
            api_client = APIClient()
            data_processor = DataProcessor()
            threshold_manager = ThresholdManager()
            deviation_analyzer = DeviationAnalyzer()
            reason_code_mapper = ReasonCodeMapper()
            file_loader = FileDataLoader()
            
            # Load trade data based on selected mode
            if 'trade_data' not in st.session_state or st.session_state.get('refresh_data', False):
                if sidebar_data.get('data_source_mode') == 'Sample Data':
                    enhanced_loader = EnhancedSampleLoader()
                    trade_data = enhanced_loader.load_sample_trade_data(sidebar_data)
                elif sidebar_data.get('data_source_mode') == 'Manual Upload':
                    trade_data = load_trade_data_from_files(file_loader, sidebar_data)
                else:
                    trade_data = load_trade_data(api_client, sidebar_data)
                st.session_state.trade_data = trade_data
                st.session_state.refresh_data = False
            
            # Load exception data based on selected mode
            if 'exception_data' not in st.session_state or st.session_state.get('refresh_exception_data', False):
                if sidebar_data.get('data_source_mode') == 'Sample Data':
                    enhanced_loader = EnhancedSampleLoader()
                    exception_data = enhanced_loader.load_sample_exception_data(sidebar_data)
                elif sidebar_data.get('data_source_mode') == 'Manual Upload':
                    exception_data = load_exception_data_from_file(file_loader, sidebar_data)
                else:
                    exception_data = load_exception_data(api_client, sidebar_data)
                st.session_state.exception_data = exception_data
                st.session_state.refresh_exception_data = False
            
            # Process thresholds
            if sidebar_data.get('data_source_mode') == 'Sample Data':
                # Load sample threshold configuration
                enhanced_loader = EnhancedSampleLoader()
                threshold_df = enhanced_loader.load_sample_threshold_config()
                if not threshold_df.empty:
                    st.session_state.threshold_df = threshold_df
                    st.session_state.threshold_mode = 'currency'  # Default for sample
                
                # Load sample reason codes
                reason_code_mapping = enhanced_loader.load_sample_reason_codes()
                if not reason_code_mapping.empty:
                    st.session_state.reason_code_mapping = reason_code_mapping
                    
            elif sidebar_data.get('threshold_file') is not None:
                threshold_df = threshold_manager.process_threshold_file(
                    sidebar_data['threshold_file'],
                    sidebar_data.get('threshold_mode', 'group')
                )
                st.session_state.threshold_df = threshold_df
            
            # Perform impact analysis
            if 'threshold_df' in st.session_state:
                perform_impact_analysis(
                    deviation_analyzer, 
                    reason_code_mapper,
                    sidebar_data
                )
            
        except Exception as e:
            st.error(f"Error processing data: {str(e)}")
            st.exception(e)

def load_trade_data(api_client, sidebar_data):
    """Load trade data from UAT and PROD APIs"""
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    try:
        # Extract parameters
        product_types = sidebar_data.get('product_types', [])
        legal_entities = sidebar_data.get('legal_entities', [])
        source_systems = sidebar_data.get('source_systems', [])
        start_date = sidebar_data.get('start_date')
        end_date = sidebar_data.get('end_date')
        
        # Generate download tasks
        tasks = []
        for product_type in product_types:
            for legal_entity in legal_entities:
                for source_system in source_systems:
                    tasks.append({
                        'product_type': product_type,
                        'legal_entity': legal_entity,
                        'source_system': source_system,
                        'start_date': start_date,
                        'end_date': end_date
                    })
        
        # Download data in parallel
        all_trade_data = []
        completed_tasks = 0
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_task = {
                executor.submit(api_client.download_trade_data, task): task 
                for task in tasks
            }
            
            for future in future_to_task:
                try:
                    uat_data, prod_data = future.result()
                    task = future_to_task[future]
                    
                    # Filter UAT data to only include trade_ids present in PROD
                    if not uat_data.empty and not prod_data.empty:
                        prod_trade_ids = set(prod_data['trade_id'].unique())
                        filtered_uat = uat_data[uat_data['trade_id'].isin(prod_trade_ids)]
                        
                        # Exclude "out of scope" trades
                        filtered_uat = filtered_uat[
                            ~filtered_uat['alert_description'].str.contains(
                                'out of scope', case=False, na=False
                            )
                        ]
                        
                        all_trade_data.append(filtered_uat)
                    
                    completed_tasks += 1
                    progress_bar.progress(completed_tasks / len(tasks))
                    status_text.text(f"Processed {completed_tasks}/{len(tasks)} data sources")
                    
                except Exception as e:
                    st.warning(f"Failed to load data for task {future_to_task[future]}: {str(e)}")
        
        # Combine all trade data
        if all_trade_data:
            combined_data = pd.concat(all_trade_data, ignore_index=True)
            status_text.text(f"✅ Successfully loaded {len(combined_data)} trade records")
            return combined_data
        else:
            status_text.text("⚠️ No trade data loaded")
            return pd.DataFrame()
            
    except Exception as e:
        st.error(f"Error loading trade data: {str(e)}")
        return pd.DataFrame()
    finally:
        progress_bar.empty()

def load_exception_data(api_client, sidebar_data):
    """Load exception data from API"""
    
    try:
        start_date = sidebar_data.get('start_date')
        end_date = sidebar_data.get('end_date', date.today())
        
        exception_data = api_client.download_exception_data(start_date, end_date)
        
        if not exception_data.empty:
            st.success(f"✅ Loaded {len(exception_data)} exception records")
        else:
            st.warning("⚠️ No exception data found for the selected date range")
            
        return exception_data
        
    except Exception as e:
        st.error(f"Error loading exception data: {str(e)}")
        return pd.DataFrame()

def load_trade_data_from_files(file_loader, sidebar_data):
    """Load trade data from uploaded files"""
    try:
        trade_files = sidebar_data.get('trade_files', {})
        product_types = sidebar_data.get('product_types', [])
        legal_entities = sidebar_data.get('legal_entities', [])
        source_systems = sidebar_data.get('source_systems', [])
        
        # Validate file completeness
        validation = file_loader.validate_file_completeness(trade_files, product_types, legal_entities, source_systems)
        
        if not validation['complete']:
            missing_files = ', '.join(validation['missing_files'])
            st.warning(f"⚠️ Missing files for: {missing_files}")
            st.info(f"📊 Uploaded {validation['uploaded_count']}/{validation['expected_count']} required files")
        
        # Load data from uploaded files
        trade_data = file_loader.load_trade_data_from_files(trade_files, sidebar_data)
        return trade_data
        
    except Exception as e:
        st.error(f"Error loading trade data from files: {str(e)}")
        return pd.DataFrame()

def load_exception_data_from_file(file_loader, sidebar_data):
    """Load exception data from uploaded file"""
    try:
        exception_file = sidebar_data.get('exception_file')
        exception_data = file_loader.load_exception_data_from_file(exception_file, sidebar_data)
        return exception_data
        
    except Exception as e:
        st.error(f"Error loading exception data from file: {str(e)}")
        return pd.DataFrame()

def perform_impact_analysis(deviation_analyzer, reason_code_mapper, sidebar_data):
    """Perform comprehensive impact analysis"""
    
    try:
        trade_data = st.session_state.get('trade_data', pd.DataFrame())
        exception_data = st.session_state.get('exception_data', pd.DataFrame())
        threshold_df = st.session_state.get('threshold_df', pd.DataFrame())
        reason_code_file = sidebar_data.get('reason_code_file')
        
        if trade_data.empty or threshold_df.empty:
            return
        
        # Apply thresholds and identify alerts
        alerts_df = deviation_analyzer.apply_thresholds(trade_data, threshold_df)
        st.session_state.alerts_df = alerts_df
        
        # Create deviation bucket summaries
        groupwise_summary = deviation_analyzer.create_groupwise_summary(alerts_df, threshold_df)
        expanded_summary = deviation_analyzer.create_expanded_summary(alerts_df, threshold_df)
        
        st.session_state.groupwise_summary = groupwise_summary
        st.session_state.expanded_summary = expanded_summary
        
        # Process reason codes if file is provided
        if reason_code_file is not None and not exception_data.empty:
            reason_code_mapping = reason_code_mapper.process_reason_code_file(reason_code_file)
            
            # Cross-reference alerts with exception data
            ops_analysis = reason_code_mapper.analyze_ops_workflow(
                alerts_df, exception_data, reason_code_mapping
            )
            st.session_state.ops_analysis = ops_analysis
        
        # Create legal entity impact analysis
        legal_entity_summary = deviation_analyzer.create_legal_entity_summary(
            alerts_df, threshold_df
        )
        st.session_state.legal_entity_summary = legal_entity_summary
        
    except Exception as e:
        st.error(f"Error in impact analysis: {str(e)}")
        st.exception(e)

if __name__ == "__main__":
    main()
