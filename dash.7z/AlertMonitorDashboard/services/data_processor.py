import pandas as pd
import numpy as np
from datetime import datetime
import streamlit as st

class DataProcessor:
    """Handle data processing and transformation operations"""
    
    def __init__(self):
        pass
    
    def validate_trade_data(self, df):
        """Validate trade data structure"""
        required_columns = [
            'trade_id', 'ccypair', 'deviationpercent', 
            'alert_description', 'legal_entity', 'source_system'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
        
        return True
    
    def validate_exception_data(self, df):
        """Validate exception data structure"""
        required_columns = [
            'trade_id', 'status', 'reasoncodeid', 'last_comment'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns in exception data: {missing_columns}")
        
        return True
    
    def extract_currencies(self, ccypair):
        """Extract CCY1 and CCY2 from currency pair"""
        if pd.isna(ccypair) or len(ccypair) != 6:
            return None, None
        
        ccy1 = ccypair[:3]
        ccy2 = ccypair[3:]
        
        return ccy1, ccy2
    
    def clean_deviation_percent(self, df):
        """Clean and validate deviation percentage values"""
        # Convert to numeric, replacing any non-numeric values with NaN
        df['deviationpercent'] = pd.to_numeric(df['deviationpercent'], errors='coerce')
        
        # Remove rows with invalid deviation percentages
        initial_count = len(df)
        df = df.dropna(subset=['deviationpercent'])
        final_count = len(df)
        
        if initial_count != final_count:
            st.info(f"Removed {initial_count - final_count} rows with invalid deviation percentages")
        
        return df
    
    def filter_out_of_scope_trades(self, df):
        """Filter out trades marked as 'out of scope'"""
        if 'alert_description' not in df.columns:
            return df
        
        initial_count = len(df)
        
        # Case-insensitive substring check for "out of scope"
        mask = ~df['alert_description'].str.contains(
            'out of scope', case=False, na=False
        )
        
        filtered_df = df[mask]
        final_count = len(filtered_df)
        
        if initial_count != final_count:
            st.info(f"Filtered out {initial_count - final_count} 'out of scope' trades")
        
        return filtered_df
    
    def cross_reference_uat_prod(self, uat_df, prod_df):
        """Cross-reference UAT data with PROD data based on trade_id"""
        if uat_df.empty or prod_df.empty:
            return uat_df
        
        # Get unique trade_ids from PROD
        prod_trade_ids = set(prod_df['trade_id'].unique())
        
        # Filter UAT data to only include trade_ids present in PROD
        initial_count = len(uat_df)
        filtered_uat = uat_df[uat_df['trade_id'].isin(prod_trade_ids)]
        final_count = len(filtered_uat)
        
        if initial_count != final_count:
            st.info(f"Cross-reference filtering: {final_count}/{initial_count} UAT trades found in PROD")
        
        return filtered_uat
    
    def aggregate_data_by_entity(self, df, group_by_columns):
        """Aggregate data by specified grouping columns"""
        try:
            if df.empty:
                return pd.DataFrame()
            
            # Basic aggregation
            agg_df = df.groupby(group_by_columns).agg({
                'trade_id': 'count',
                'deviationpercent': ['mean', 'max', 'std']
            }).reset_index()
            
            # Flatten column names
            agg_df.columns = [
                col[0] if col[1] == '' else f"{col[0]}_{col[1]}"
                for col in agg_df.columns
            ]
            
            # Rename for clarity
            rename_map = {
                'trade_id_count': 'total_trades',
                'deviationpercent_mean': 'avg_deviation',
                'deviationpercent_max': 'max_deviation',
                'deviationpercent_std': 'std_deviation'
            }
            
            agg_df = agg_df.rename(columns=rename_map)
            
            return agg_df
            
        except Exception as e:
            st.error(f"Error in data aggregation: {str(e)}")
            return pd.DataFrame()
    
    def calculate_volume_metrics(self, df):
        """Calculate volume and trade metrics"""
        if df.empty:
            return {}
        
        metrics = {
            'total_volume': len(df),
            'unique_trade_ids': df['trade_id'].nunique(),
            'unique_currency_pairs': df['ccypair'].nunique() if 'ccypair' in df.columns else 0,
            'avg_deviation': df['deviationpercent'].mean() if 'deviationpercent' in df.columns else 0,
            'max_deviation': df['deviationpercent'].max() if 'deviationpercent' in df.columns else 0
        }
        
        return metrics
