import pandas as pd
import numpy as np
import streamlit as st

class DeviationAnalyzer:
    """Analyze trade deviations and create summaries"""
    
    def __init__(self):
        pass
    
    def apply_thresholds(self, trade_data, threshold_df):
        """Apply threshold logic to identify alerts"""
        try:
            if trade_data.empty or threshold_df.empty:
                return pd.DataFrame()
            
            alerts = []
            
            for _, trade in trade_data.iterrows():
                # Extract currencies from ccypair
                ccypair = trade.get('ccypair', '')
                if not ccypair or len(ccypair) != 6:
                    continue
                
                ccy1 = ccypair[:3]
                ccy2 = ccypair[3:]
                legal_entity = trade.get('legal_entity', '')
                deviation_percent = trade.get('deviationpercent', 0)
                
                # Get thresholds for both currencies
                threshold1 = self._get_currency_threshold(legal_entity, ccy1, threshold_df)
                threshold2 = self._get_currency_threshold(legal_entity, ccy2, threshold_df)
                
                # Use maximum threshold
                max_threshold = max(threshold1, threshold2)
                
                # Check if this is an alert
                if deviation_percent > max_threshold:
                    alert_record = trade.copy()
                    alert_record['ccy1'] = ccy1
                    alert_record['ccy2'] = ccy2
                    alert_record['threshold_used'] = max_threshold
                    alert_record['threshold_ccy1'] = threshold1
                    alert_record['threshold_ccy2'] = threshold2
                    alerts.append(alert_record)
            
            alerts_df = pd.DataFrame(alerts)
            
            if not alerts_df.empty:
                st.success(f"✅ Identified {len(alerts_df)} alerts from {len(trade_data)} trades")
            else:
                st.info("ℹ️ No alerts identified with current thresholds")
            
            return alerts_df
            
        except Exception as e:
            st.error(f"Error applying thresholds: {str(e)}")
            return pd.DataFrame()
    
    def create_groupwise_summary(self, alerts_df, threshold_df):
        """Create groupwise deviation bucket summary"""
        try:
            if alerts_df.empty:
                return pd.DataFrame()
            
            # Create dynamic buckets based on thresholds
            buckets = self._create_dynamic_buckets(threshold_df)
            
            # Map alerts to buckets for both currencies
            bucket_counts = {}
            
            for _, alert in alerts_df.iterrows():
                deviation = alert['deviationpercent']
                bucket_label = self._get_bucket_label(deviation, buckets)
                
                # Count for both currencies
                for ccy in [alert['ccy1'], alert['ccy2']]:
                    if bucket_label not in bucket_counts:
                        bucket_counts[bucket_label] = {}
                    if ccy not in bucket_counts[bucket_label]:
                        bucket_counts[bucket_label][ccy] = 0
                    bucket_counts[bucket_label][ccy] += 1
            
            # Convert to DataFrame
            if bucket_counts:
                summary_df = pd.DataFrame(bucket_counts).T.fillna(0)
                
                # Ensure all values are numeric and handle any broadcasting issues
                for col in summary_df.columns:
                    if col != 'index':
                        summary_df[col] = pd.to_numeric(summary_df[col], errors='coerce').fillna(0).astype(int)
                
                # Add bucket range information
                summary_df = summary_df.reset_index()
                summary_df = summary_df.rename(columns={'index': 'Deviation_Bucket'})
                
                # Add highlighting information for buckets above max threshold
                if not threshold_df.empty and 'Adjusted_Threshold' in threshold_df.columns:
                    max_threshold = threshold_df['Adjusted_Threshold'].max()
                    summary_df['highlight'] = summary_df['Deviation_Bucket'].apply(
                        lambda x: self._should_highlight_bucket(x, max_threshold)
                    )
                else:
                    summary_df['highlight'] = False
                
                # Remove columns with all zeros (but keep essential columns)
                essential_cols = ['Deviation_Bucket', 'highlight']
                numeric_cols = [col for col in summary_df.columns if col not in essential_cols]
                
                if numeric_cols:
                    cols_to_keep = essential_cols + [col for col in numeric_cols 
                                                   if summary_df[col].sum() > 0]
                    summary_df = summary_df[cols_to_keep]
                
                return summary_df
            else:
                return pd.DataFrame()
                
        except Exception as e:
            st.error(f"Error creating groupwise summary: {str(e)}")
            return pd.DataFrame()
    
    def create_expanded_summary(self, alerts_df, threshold_df, bin_size=0.5):
        """Create expanded bucket summary for alerts above max threshold"""
        try:
            if alerts_df.empty or threshold_df.empty:
                return pd.DataFrame()
            
            max_threshold = threshold_df['Adjusted_Threshold'].max()
            
            # Filter alerts above max threshold
            high_deviation_alerts = alerts_df[alerts_df['deviationpercent'] > max_threshold]
            
            if high_deviation_alerts.empty:
                return pd.DataFrame()
            
            # Create fixed-size bins from max_threshold to max_deviation
            max_deviation = high_deviation_alerts['deviationpercent'].max()
            
            # Round max_deviation up to nearest bin_size
            max_bin_edge = np.ceil(max_deviation / bin_size) * bin_size
            
            # Create bin edges
            bin_edges = np.arange(max_threshold, max_bin_edge + bin_size, bin_size)
            
            # Create bin labels
            bin_labels = [f"{edge:.1f} - {edge + bin_size:.1f}" 
                         for edge in bin_edges[:-1]]
            
            # Assign alerts to bins for both currencies
            bucket_counts = {}
            
            for _, alert in high_deviation_alerts.iterrows():
                deviation = alert['deviationpercent']
                bin_idx = np.digitize(deviation, bin_edges) - 1
                
                if 0 <= bin_idx < len(bin_labels):
                    bucket_label = bin_labels[bin_idx]
                    
                    # Count for both currencies
                    for ccy in [alert['ccy1'], alert['ccy2']]:
                        if bucket_label not in bucket_counts:
                            bucket_counts[bucket_label] = {}
                        if ccy not in bucket_counts[bucket_label]:
                            bucket_counts[bucket_label][ccy] = 0
                        bucket_counts[bucket_label][ccy] += 1
            
            # Convert to DataFrame
            if bucket_counts:
                expanded_df = pd.DataFrame(bucket_counts).T.fillna(0).astype(int)
                expanded_df = expanded_df.reset_index()
                expanded_df = expanded_df.rename(columns={'index': 'Deviation_Bucket'})
                
                # All rows should be highlighted as they're above max threshold
                expanded_df['highlight'] = True
                
                return expanded_df
            else:
                return pd.DataFrame()
                
        except Exception as e:
            st.error(f"Error creating expanded summary: {str(e)}")
            return pd.DataFrame()
    
    def create_legal_entity_summary(self, alerts_df, threshold_df):
        """Create legal entity impact analysis summary"""
        try:
            if alerts_df.empty:
                return pd.DataFrame()
            
            # Group by legal entity and source system
            summary_data = []
            
            for (legal_entity, source_system), group in alerts_df.groupby(['legal_entity', 'source_system']):
                total_vol = len(group)
                
                # Count original alerts (using original thresholds)
                org_alerts = self._count_alerts_with_thresholds(group, threshold_df, 'Original_Threshold')
                
                # Count projected alerts (using proposed thresholds)  
                proj_alerts = self._count_alerts_with_thresholds(group, threshold_df, 'Proposed_Threshold')
                
                # Count adjusted alerts (using adjusted thresholds)
                adj_alerts = len(group)  # Current alerts are already based on adjusted thresholds
                
                summary_data.append({
                    'LegalEntity': legal_entity,
                    'SourceSystem': source_system,
                    'TotalVol': total_vol,
                    'OrgAlerts': org_alerts,
                    'ProjAlerts': proj_alerts,
                    'AdjustedAlerts': adj_alerts
                })
            
            return pd.DataFrame(summary_data)
            
        except Exception as e:
            st.error(f"Error creating legal entity summary: {str(e)}")
            return pd.DataFrame()
    
    def _get_currency_threshold(self, legal_entity, currency, threshold_df):
        """Get threshold for specific currency and legal entity"""
        # First try exact match
        exact_match = threshold_df[
            (threshold_df['LegalEntity'] == legal_entity) &
            (threshold_df['CCY'] == currency)
        ]
        
        if not exact_match.empty:
            return exact_match.iloc[0]['Adjusted_Threshold']
        
        # Try fallback to "ALL"
        fallback_match = threshold_df[
            (threshold_df['LegalEntity'] == 'ALL') &
            (threshold_df['CCY'] == currency)
        ]
        
        if not fallback_match.empty:
            return fallback_match.iloc[0]['Adjusted_Threshold']
        
        # Default threshold
        return 1.0
    
    def _create_dynamic_buckets(self, threshold_df):
        """Create dynamic buckets based on threshold values"""
        unique_thresholds = sorted(threshold_df['Adjusted_Threshold'].unique())
        
        buckets = []
        for i, threshold in enumerate(unique_thresholds):
            if i == 0:
                lower_bound = 0
            else:
                lower_bound = unique_thresholds[i-1]
            
            buckets.append({
                'lower_bound': lower_bound,
                'upper_bound': threshold,
                'label': f"{lower_bound:.2f} - {threshold:.2f}"
            })
        
        # Add final bucket
        if unique_thresholds:
            buckets.append({
                'lower_bound': unique_thresholds[-1],
                'upper_bound': float('inf'),
                'label': f"{unique_thresholds[-1]:.2f} - inf"
            })
        
        return buckets
    
    def _get_bucket_label(self, deviation, buckets):
        """Get bucket label for a deviation value"""
        for bucket in buckets:
            if bucket['lower_bound'] < deviation <= bucket['upper_bound']:
                return bucket['label']
        return "Unknown"
    
    def _should_highlight_bucket(self, bucket_label, max_threshold):
        """Check if bucket should be highlighted"""
        try:
            # Extract lower bound from bucket label
            lower_bound = float(bucket_label.split(' - ')[0])
            return lower_bound > max_threshold
        except:
            return False
    
    def _count_alerts_with_thresholds(self, group, threshold_df, threshold_column):
        """Count alerts using specific threshold column"""
        count = 0
        
        for _, trade in group.iterrows():
            legal_entity = trade.get('legal_entity', '')
            ccy1 = trade.get('ccy1', '')
            ccy2 = trade.get('ccy2', '')
            deviation = trade.get('deviationpercent', 0)
            
            # Get thresholds for both currencies
            threshold1 = self._get_threshold_for_column(legal_entity, ccy1, threshold_df, threshold_column)
            threshold2 = self._get_threshold_for_column(legal_entity, ccy2, threshold_df, threshold_column)
            
            max_threshold = max(threshold1, threshold2)
            
            if deviation > max_threshold:
                count += 1
        
        return count
    
    def _get_threshold_for_column(self, legal_entity, currency, threshold_df, threshold_column):
        """Get threshold from specific column"""
        # First try exact match
        exact_match = threshold_df[
            (threshold_df['LegalEntity'] == legal_entity) &
            (threshold_df['CCY'] == currency)
        ]
        
        if not exact_match.empty:
            return exact_match.iloc[0][threshold_column]
        
        # Try fallback to "ALL"
        fallback_match = threshold_df[
            (threshold_df['LegalEntity'] == 'ALL') &
            (threshold_df['CCY'] == currency)
        ]
        
        if not fallback_match.empty:
            return fallback_match.iloc[0][threshold_column]
        
        # Default threshold
        return 1.0
