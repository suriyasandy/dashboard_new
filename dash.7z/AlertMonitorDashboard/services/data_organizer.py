import pandas as pd
import os
from datetime import datetime
import logging

class DataOrganizer:
    """Organize and manage dataset directory structure according to requirements"""
    
    def __init__(self):
        self.base_dir = "dataset"
        self.omrc_dir = os.path.join(self.base_dir, "omrc_data")
        self.exception_dir = os.path.join(self.base_dir, "exception_data")
        
        # Create directory structure
        self._create_directory_structure()
    
    def _create_directory_structure(self):
        """Create required directory structure"""
        
        directories = [
            os.path.join(self.omrc_dir, "prod"),
            os.path.join(self.omrc_dir, "uat"),
            os.path.join(self.omrc_dir, "sample"),
            self.exception_dir
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    def save_consolidated_trade_data(self, uat_data, prod_data, filtered_uat_data, metadata):
        """Save consolidated trade data files according to requirements"""
        
        try:
            legal_entity = metadata.get('legal_entity', 'Entity1')
            source_system = metadata.get('source_system', 'SYSTEM_A')
            start_date = metadata.get('start_date', datetime.now().strftime('%Y%m%d'))
            end_date = metadata.get('end_date', datetime.now().strftime('%Y%m%d'))
            
            # File naming pattern: LegalEntity_SourceSystem_StartDate_EndDate.csv
            filename_base = f"{legal_entity}_{source_system}_{start_date}_{end_date}"
            
            # Save UAT data
            if not uat_data.empty:
                uat_filepath = os.path.join(self.omrc_dir, "uat", f"consolidated_UAT_{filename_base}.csv")
                uat_data.to_csv(uat_filepath, index=False)
                logging.info(f"Saved UAT data: {uat_filepath}")
            
            # Save PROD data
            if not prod_data.empty:
                prod_filepath = os.path.join(self.omrc_dir, "prod", f"consolidated_PROD_{filename_base}.csv")
                prod_data.to_csv(prod_filepath, index=False)
                logging.info(f"Saved PROD data: {prod_filepath}")
            
            # Save filtered UAT data (for impact analysis)
            if not filtered_uat_data.empty:
                filtered_filepath = os.path.join(self.omrc_dir, "sample", f"filtered_UAT_{filename_base}.csv")
                filtered_uat_data.to_csv(filtered_filepath, index=False)
                logging.info(f"Saved filtered UAT data: {filtered_filepath}")
            
            return {
                'uat_file': uat_filepath if not uat_data.empty else None,
                'prod_file': prod_filepath if not prod_data.empty else None,
                'filtered_file': filtered_filepath if not filtered_uat_data.empty else None
            }
            
        except Exception as e:
            logging.error(f"Error saving consolidated trade data: {str(e)}")
            return {}
    
    def save_consolidated_exception_data(self, exception_data, start_date, current_date):
        """Save consolidated exception data"""
        
        try:
            filename = f"consolidated_epe_data_{start_date}_{current_date}.csv"
            filepath = os.path.join(self.exception_dir, filename)
            
            if not exception_data.empty:
                exception_data.to_csv(filepath, index=False)
                logging.info(f"Saved exception data: {filepath}")
                return filepath
            
            return None
            
        except Exception as e:
            logging.error(f"Error saving exception data: {str(e)}")
            return None
    
    def load_consolidated_data(self, legal_entity, source_system, start_date, end_date, data_type='filtered'):
        """Load consolidated data from saved files"""
        
        try:
            filename_base = f"{legal_entity}_{source_system}_{start_date}_{end_date}"
            
            if data_type == 'uat':
                filepath = os.path.join(self.omrc_dir, "uat", f"consolidated_UAT_{filename_base}.csv")
            elif data_type == 'prod':
                filepath = os.path.join(self.omrc_dir, "prod", f"consolidated_PROD_{filename_base}.csv")
            else:  # filtered
                filepath = os.path.join(self.omrc_dir, "sample", f"filtered_UAT_{filename_base}.csv")
            
            if os.path.exists(filepath):
                return pd.read_csv(filepath)
            else:
                logging.warning(f"File not found: {filepath}")
                return pd.DataFrame()
                
        except Exception as e:
            logging.error(f"Error loading consolidated data: {str(e)}")
            return pd.DataFrame()
    
    def load_exception_data_by_date(self, start_date, end_date=None):
        """Load exception data by date range"""
        
        try:
            if end_date is None:
                end_date = datetime.now().strftime('%Y%m%d')
            
            filename = f"consolidated_epe_data_{start_date}_{end_date}.csv"
            filepath = os.path.join(self.exception_dir, filename)
            
            if os.path.exists(filepath):
                return pd.read_csv(filepath)
            else:
                logging.warning(f"Exception data file not found: {filepath}")
                return pd.DataFrame()
                
        except Exception as e:
            logging.error(f"Error loading exception data: {str(e)}")
            return pd.DataFrame()
    
    def get_available_datasets(self):
        """Get list of available consolidated datasets"""
        
        datasets = {
            'uat_files': [],
            'prod_files': [],
            'filtered_files': [],
            'exception_files': []
        }
        
        try:
            # UAT files
            uat_dir = os.path.join(self.omrc_dir, "uat")
            if os.path.exists(uat_dir):
                datasets['uat_files'] = [f for f in os.listdir(uat_dir) if f.endswith('.csv')]
            
            # PROD files
            prod_dir = os.path.join(self.omrc_dir, "prod")
            if os.path.exists(prod_dir):
                datasets['prod_files'] = [f for f in os.listdir(prod_dir) if f.endswith('.csv')]
            
            # Filtered files
            sample_dir = os.path.join(self.omrc_dir, "sample")
            if os.path.exists(sample_dir):
                datasets['filtered_files'] = [f for f in os.listdir(sample_dir) if f.endswith('.csv')]
            
            # Exception files
            if os.path.exists(self.exception_dir):
                datasets['exception_files'] = [f for f in os.listdir(self.exception_dir) if f.endswith('.csv')]
            
        except Exception as e:
            logging.error(f"Error getting available datasets: {str(e)}")
        
        return datasets
    
    def cleanup_old_files(self, days_old=30):
        """Clean up files older than specified days"""
        
        try:
            import time
            cutoff_time = time.time() - (days_old * 24 * 60 * 60)
            
            all_dirs = [
                os.path.join(self.omrc_dir, "uat"),
                os.path.join(self.omrc_dir, "prod"),
                os.path.join(self.omrc_dir, "sample"),
                self.exception_dir
            ]
            
            cleaned_files = []
            
            for directory in all_dirs:
                if os.path.exists(directory):
                    for filename in os.listdir(directory):
                        filepath = os.path.join(directory, filename)
                        if os.path.isfile(filepath):
                            file_time = os.path.getmtime(filepath)
                            if file_time < cutoff_time:
                                os.remove(filepath)
                                cleaned_files.append(filepath)
                                logging.info(f"Cleaned up old file: {filepath}")
            
            return cleaned_files
            
        except Exception as e:
            logging.error(f"Error during cleanup: {str(e)}")
            return []
    
    def get_directory_info(self):
        """Get information about directory structure and file counts"""
        
        info = {
            'base_directory': self.base_dir,
            'structure': {
                'omrc_data': {
                    'uat': {'path': os.path.join(self.omrc_dir, "uat"), 'file_count': 0},
                    'prod': {'path': os.path.join(self.omrc_dir, "prod"), 'file_count': 0},
                    'sample': {'path': os.path.join(self.omrc_dir, "sample"), 'file_count': 0}
                },
                'exception_data': {'path': self.exception_dir, 'file_count': 0}
            }
        }
        
        try:
            # Count files in each directory
            for category, sub_dirs in info['structure'].items():
                if isinstance(sub_dirs, dict) and 'path' in sub_dirs:
                    # Single directory (exception_data)
                    if os.path.exists(sub_dirs['path']):
                        sub_dirs['file_count'] = len([f for f in os.listdir(sub_dirs['path']) if f.endswith('.csv')])
                else:
                    # Multiple subdirectories (omrc_data)
                    for sub_name, sub_info in sub_dirs.items():
                        if os.path.exists(sub_info['path']):
                            sub_info['file_count'] = len([f for f in os.listdir(sub_info['path']) if f.endswith('.csv')])
            
        except Exception as e:
            logging.error(f"Error getting directory info: {str(e)}")
        
        return info