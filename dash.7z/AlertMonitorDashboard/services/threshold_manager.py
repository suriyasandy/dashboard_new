import pandas as pd
import numpy as np
import streamlit as st

class ThresholdManager:
    """Manage threshold configurations and applications"""
    
    def __init__(self):
        self.default_thresholds = {
            'Group1': 1.0,
            'Group2': 1.5,
            'Group3': 2.0
        }
    
    def process_threshold_file(self, uploaded_file, threshold_mode='group'):
        """Process uploaded threshold file and add derived columns"""
        try:
            # Read the uploaded file
            df = pd.read_csv(uploaded_file)
            
            # Validate required columns
            required_columns = [
                'LegalEntity', 'CCY', 'Original_Group', 'Original_Threshold',
                'Proposed_Group', 'Proposed_Threshold'
            ]
            
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
            
            # Add derived columns
            df['Adjusted_Group'] = df['Proposed_Group'].copy()
            df['Adjusted_Threshold'] = df['Proposed_Threshold'].copy()
            
            # Store threshold mode for later use
            df.attrs['threshold_mode'] = threshold_mode
            
            return df
            
        except Exception as e:
            st.error(f"Error processing threshold file: {str(e)}")
            return pd.DataFrame()
    
    def get_threshold_for_trade(self, trade_row, threshold_df):
        """Get applicable threshold for a specific trade"""
        try:
            legal_entity = trade_row.get('legal_entity', '')
            ccypair = trade_row.get('ccypair', '')
            
            if not ccypair or len(ccypair) != 6:
                return self._get_default_threshold()
            
            ccy1 = ccypair[:3]
            ccy2 = ccypair[3:]
            
            # Get thresholds for both currencies
            threshold1 = self._get_currency_threshold(legal_entity, ccy1, threshold_df)
            threshold2 = self._get_currency_threshold(legal_entity, ccy2, threshold_df)
            
            # Return the maximum threshold
            return max(threshold1, threshold2)
            
        except Exception as e:
            return self._get_default_threshold()
    
    def _get_currency_threshold(self, legal_entity, currency, threshold_df):
        """Get threshold for specific legal entity and currency"""
        try:
            # First try exact match on legal entity and currency
            exact_match = threshold_df[
                (threshold_df['LegalEntity'] == legal_entity) &
                (threshold_df['CCY'] == currency)
            ]
            
            if not exact_match.empty:
                return exact_match.iloc[0]['Adjusted_Threshold']
            
            # Try fallback to "ALL" legal entity
            fallback_match = threshold_df[
                (threshold_df['LegalEntity'] == 'ALL') &
                (threshold_df['CCY'] == currency)
            ]
            
            if not fallback_match.empty:
                return fallback_match.iloc[0]['Adjusted_Threshold']
            
            # Use default threshold for Group1
            return self._get_default_threshold()
            
        except Exception as e:
            return self._get_default_threshold()
    
    def _get_default_threshold(self):
        """Get default threshold for Group1"""
        return self.default_thresholds.get('Group1', 1.0)
    
    def create_threshold_buckets(self, threshold_df):
        """Create dynamic threshold buckets for analysis"""
        try:
            if threshold_df.empty:
                return []
            
            # Get unique adjusted thresholds in ascending order
            unique_thresholds = sorted(threshold_df['Adjusted_Threshold'].unique())
            
            # Create bucket ranges
            buckets = []
            for i, threshold in enumerate(unique_thresholds):
                if i == 0:
                    lower_bound = 0
                else:
                    lower_bound = unique_thresholds[i-1]
                
                upper_bound = threshold
                
                buckets.append({
                    'lower_bound': lower_bound,
                    'upper_bound': upper_bound,
                    'label': f"{lower_bound:.2f} - {upper_bound:.2f}"
                })
            
            # Add final bucket for values above the highest threshold
            if unique_thresholds:
                buckets.append({
                    'lower_bound': unique_thresholds[-1],
                    'upper_bound': float('inf'),
                    'label': f"{unique_thresholds[-1]:.2f} - inf"
                })
            
            return buckets
            
        except Exception as e:
            st.error(f"Error creating threshold buckets: {str(e)}")
            return []
    
    def update_adjusted_thresholds(self, threshold_df, updates):
        """Update adjusted threshold values based on user input"""
        try:
            updated_df = threshold_df.copy()
            
            for index, update in updates.items():
                if index < len(updated_df):
                    if 'Adjusted_Group' in update:
                        updated_df.loc[index, 'Adjusted_Group'] = update['Adjusted_Group']
                    if 'Adjusted_Threshold' in update:
                        updated_df.loc[index, 'Adjusted_Threshold'] = float(update['Adjusted_Threshold'])
            
            return updated_df
            
        except Exception as e:
            st.error(f"Error updating thresholds: {str(e)}")
            return threshold_df
    
    def validate_threshold_updates(self, updates):
        """Validate threshold update values"""
        errors = []
        
        for index, update in updates.items():
            if 'Adjusted_Threshold' in update:
                try:
                    threshold_value = float(update['Adjusted_Threshold'])
                    if threshold_value < 0:
                        errors.append(f"Row {index}: Threshold must be non-negative")
                    if threshold_value > 100:
                        errors.append(f"Row {index}: Threshold seems unusually high (>100%)")
                except ValueError:
                    errors.append(f"Row {index}: Invalid threshold value")
        
        return errors
