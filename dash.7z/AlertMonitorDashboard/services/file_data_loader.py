import pandas as pd
import streamlit as st
import io
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

class FileDataLoader:
    """Handle manual file uploads for trade and exception data"""
    
    def __init__(self):
        pass
    
    def load_trade_data_from_files(self, trade_files, sidebar_data):
        """Load and combine trade data from uploaded files"""
        try:
            if not trade_files:
                st.warning("⚠️ No trade files uploaded")
                return pd.DataFrame()
            
            st.info(f"📊 Processing {len(trade_files)} uploaded files...")
            
            all_trade_data = []
            product_types = sidebar_data.get('product_types', [])
            start_date = sidebar_data.get('start_date')
            end_date = sidebar_data.get('end_date')
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Process each uploaded file
            total_files = len(trade_files)
            processed_files = 0
            
            for file_key, uploaded_file in trade_files.items():
                try:
                    # Parse file key to get product type, legal entity and source system
                    # Format: ProductType_LegalEntity_SourceSystem
                    parts = file_key.split('_')
                    if len(parts) >= 3:
                        product_type = parts[0]
                        legal_entity = parts[1]
                        source_system = '_'.join(parts[2:])  # Handle source systems with underscores
                    else:
                        raise ValueError(f"Invalid file key format: {file_key}")
                    
                    st.info(f"🔍 Processing {product_type} data for {legal_entity} from {source_system}")
                    
                    # Reset file pointer to beginning
                    uploaded_file.seek(0)
                    
                    # Read the uploaded file
                    file_data = pd.read_csv(uploaded_file)
                    
                    st.info(f"📄 File {file_key}: {len(file_data)} rows loaded")
                    
                    # Validate required columns
                    self._validate_trade_file_structure(file_data, file_key)
                    
                    # Add metadata if not present
                    if 'legal_entity' not in file_data.columns:
                        file_data['legal_entity'] = legal_entity
                    if 'source_system' not in file_data.columns:
                        file_data['source_system'] = source_system
                    if 'product_type' not in file_data.columns:
                        file_data['product_type'] = product_type
                    
                    # Filter by product types if specified
                    if product_types and 'product_type' in file_data.columns:
                        before_filter = len(file_data)
                        file_data = file_data[file_data['product_type'].isin(product_types)]
                        after_filter = len(file_data)
                        st.info(f"🔍 Product filter: {before_filter} → {after_filter} records")
                    
                    # Filter by date range if specified
                    if start_date and end_date and 'trade_date' in file_data.columns:
                        before_filter = len(file_data)
                        file_data['trade_date'] = pd.to_datetime(file_data['trade_date'])
                        start_datetime = pd.to_datetime(start_date)
                        end_datetime = pd.to_datetime(end_date)
                        
                        file_data = file_data[
                            (file_data['trade_date'] >= start_datetime) &
                            (file_data['trade_date'] <= end_datetime)
                        ]
                        after_filter = len(file_data)
                        st.info(f"📅 Date filter: {before_filter} → {after_filter} records")
                    
                    # Filter out "out of scope" trades
                    if 'alert_description' in file_data.columns:
                        before_filter = len(file_data)
                        file_data = file_data[
                            ~file_data['alert_description'].str.contains(
                                'out of scope', case=False, na=False
                            )
                        ]
                        after_filter = len(file_data)
                        if before_filter != after_filter:
                            st.info(f"🚫 Scope filter: {before_filter} → {after_filter} records")
                    
                    if len(file_data) > 0:
                        all_trade_data.append(file_data)
                        st.success(f"✅ {file_key}: {len(file_data)} records added")
                    else:
                        st.warning(f"⚠️ {file_key}: No records after filtering")
                    
                    processed_files += 1
                    progress_bar.progress(processed_files / total_files)
                    status_text.text(f"Processed {processed_files}/{total_files} files: {file_key}")
                    
                except Exception as e:
                    st.error(f"❌ Failed to process file {file_key}: {str(e)}")
                    processed_files += 1
                    progress_bar.progress(processed_files / total_files)
            
            # Combine all trade data
            if all_trade_data:
                combined_data = pd.concat(all_trade_data, ignore_index=True)
                
                # Clean deviation percentages
                combined_data = self._clean_deviation_data(combined_data)
                
                st.success(f"✅ Successfully loaded {len(combined_data)} trade records from {len(all_trade_data)} files")
                status_text.text(f"✅ Data loading complete: {len(combined_data)} total records")
                return combined_data
            else:
                st.warning("⚠️ No valid trade data loaded after processing all files")
                status_text.text("⚠️ No valid trade data loaded")
                return pd.DataFrame()
                
        except Exception as e:
            st.error(f"❌ Error loading trade data from files: {str(e)}")
            return pd.DataFrame()
        finally:
            if 'progress_bar' in locals():
                progress_bar.empty()
            if 'status_text' in locals():
                status_text.empty()
    
    def load_exception_data_from_file(self, exception_file, sidebar_data):
        """Load exception data from uploaded file"""
        try:
            if exception_file is None:
                st.info("ℹ️ No exception file uploaded")
                return pd.DataFrame()
            
            # Reset file pointer to beginning
            exception_file.seek(0)
            
            # Read the uploaded file
            exception_data = pd.read_csv(exception_file)
            
            st.info(f"📋 Exception file: {len(exception_data)} rows loaded")
            
            # Validate required columns
            self._validate_exception_file_structure(exception_data)
            
            # Filter by date range if specified
            start_date = sidebar_data.get('start_date')
            end_date = sidebar_data.get('end_date')
            
            if start_date and end_date and 'processed_date' in exception_data.columns:
                before_filter = len(exception_data)
                exception_data['processed_date'] = pd.to_datetime(exception_data['processed_date'])
                start_datetime = pd.to_datetime(start_date)
                end_datetime = pd.to_datetime(end_date)
                
                exception_data = exception_data[
                    (exception_data['processed_date'] >= start_datetime) &
                    (exception_data['processed_date'] <= end_datetime)
                ]
                after_filter = len(exception_data)
                st.info(f"📅 Date filter for exceptions: {before_filter} → {after_filter} records")
            
            if not exception_data.empty:
                st.success(f"✅ Loaded {len(exception_data)} exception records")
            else:
                st.warning("⚠️ No exception data found for the selected date range")
                
            return exception_data
            
        except Exception as e:
            st.error(f"❌ Error loading exception data: {str(e)}")
            return pd.DataFrame()
    
    def _validate_trade_file_structure(self, df, file_key):
        """Validate trade file structure"""
        required_columns = [
            'trade_id', 'ccypair', 'deviationpercent'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"File {file_key} missing required columns: {missing_columns}")
        
        # Check for valid data types
        if not pd.api.types.is_numeric_dtype(df['deviationpercent']):
            # Try to convert to numeric
            df['deviationpercent'] = pd.to_numeric(df['deviationpercent'], errors='coerce')
        
        return True
    
    def _validate_exception_file_structure(self, df):
        """Validate exception file structure"""
        required_columns = [
            'trade_id', 'status'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Exception file missing required columns: {missing_columns}")
        
        return True
    
    def _clean_deviation_data(self, df):
        """Clean and validate deviation percentage data"""
        if 'deviationpercent' not in df.columns:
            return df
        
        # Convert to numeric, replacing any non-numeric values with NaN
        df['deviationpercent'] = pd.to_numeric(df['deviationpercent'], errors='coerce')
        
        # Remove rows with invalid deviation percentages
        initial_count = len(df)
        df = df.dropna(subset=['deviationpercent'])
        final_count = len(df)
        
        if initial_count != final_count:
            st.info(f"Removed {initial_count - final_count} rows with invalid deviation percentages")
        
        return df
    
    def get_file_upload_instructions(self):
        """Get instructions for file upload format"""
        return {
            'trade_files': {
                'description': 'Trade data files should contain one file per Legal Entity + Source System combination',
                'required_columns': ['trade_id', 'ccypair', 'deviationpercent'],
                'optional_columns': ['alert_description', 'product_type', 'trade_date', 'notional_amount'],
                'format': 'CSV format with headers',
                'naming': 'Files will be processed based on the Legal Entity and Source System selections'
            },
            'exception_file': {
                'description': 'Exception data file containing operational exceptions',
                'required_columns': ['trade_id', 'status'],
                'optional_columns': ['reasoncodeid', 'last_comment', 'processed_date', 'ops_user', 'priority'],
                'format': 'CSV format with headers'
            }
        }
    
    def validate_file_completeness(self, trade_files, product_types, legal_entities, source_systems):
        """Validate that all required file combinations are uploaded"""
        expected_files = []
        uploaded_files = list(trade_files.keys())
        
        for product_type in product_types:
            for legal_entity in legal_entities:
                for source_system in source_systems:
                    expected_key = f"{product_type}_{legal_entity}_{source_system}"
                    expected_files.append(expected_key)
        
        missing_files = [f for f in expected_files if f not in uploaded_files]
        extra_files = [f for f in uploaded_files if f not in expected_files]
        
        return {
            'complete': len(missing_files) == 0,
            'missing_files': missing_files,
            'extra_files': extra_files,
            'uploaded_count': len(uploaded_files),
            'expected_count': len(expected_files)
        }