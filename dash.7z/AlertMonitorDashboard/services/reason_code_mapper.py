import pandas as pd
import numpy as np
import streamlit as st

class ReasonCodeMapper:
    """Handle reason code mapping and ops workflow analysis"""
    
    def __init__(self):
        pass
    
    def process_reason_code_file(self, uploaded_file):
        """Process uploaded reason code mapping file"""
        try:
            # Read the uploaded file
            df = pd.read_csv(uploaded_file)
            
            # Validate required columns
            required_columns = ['reasoncode', 'highlevelcode']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                raise ValueError(f"Missing required columns in reason code file: {missing_columns}")
            
            # Create mapping dictionary for faster lookup
            reason_code_mapping = {}
            for _, row in df.iterrows():
                reason_code = str(row['reasoncode']).strip()
                high_level_code = str(row['highlevelcode']).strip()
                reason_code_mapping[reason_code] = high_level_code
            
            st.success(f"✅ Loaded {len(reason_code_mapping)} reason code mappings")
            
            return reason_code_mapping
            
        except Exception as e:
            st.error(f"Error processing reason code file: {str(e)}")
            return {}
    
    def analyze_ops_workflow(self, alerts_df, exception_data, reason_code_mapping):
        """Analyze ops workflow by cross-referencing alerts with exception data"""
        try:
            if alerts_df.empty or exception_data.empty:
                return pd.DataFrame()
            
            # Cross-reference alerts with exception data (KEPE matching)
            merged_data = self._cross_reference_alerts_exceptions(alerts_df, exception_data)
            
            if merged_data.empty:
                st.info("ℹ️ No matching trades found between alerts and exception data")
                return pd.DataFrame()
            
            # Analyze closed trades with reason codes
            ops_analysis = self._analyze_closed_trades(merged_data, reason_code_mapping)
            
            # Add high-level code mapping
            ops_analysis = self._map_high_level_codes(ops_analysis, reason_code_mapping)
            
            st.success(f"✅ Completed ops workflow analysis for {len(ops_analysis)} records")
            
            return ops_analysis
            
        except Exception as e:
            st.error(f"Error in ops workflow analysis: {str(e)}")
            return pd.DataFrame()
    
    def _cross_reference_alerts_exceptions(self, alerts_df, exception_data):
        """Cross-reference alerts with exception data based on trade_id"""
        try:
            # Merge on trade_id
            merged = pd.merge(
                alerts_df,
                exception_data,
                on='trade_id',
                how='inner',
                suffixes=('_alert', '_exception')
            )
            
            return merged
            
        except Exception as e:
            st.error(f"Error in cross-referencing: {str(e)}")
            return pd.DataFrame()
    
    def _analyze_closed_trades(self, merged_data, reason_code_mapping):
        """Analyze closed trades and extract reason code information"""
        try:
            # Filter for closed status trades
            closed_trades = merged_data[
                merged_data['status'].str.lower() == 'closed'
            ].copy()
            
            if closed_trades.empty:
                return pd.DataFrame()
            
            # Extract and process reason codes
            ops_analysis = []
            
            for _, trade in closed_trades.iterrows():
                analysis_record = {
                    'trade_id': trade['trade_id'],
                    'legal_entity': trade.get('legal_entity', ''),
                    'source_system': trade.get('source_system', ''),
                    'ccypair': trade.get('ccypair', ''),
                    'deviationpercent': trade.get('deviationpercent', 0),
                    'threshold_used': trade.get('threshold_used', 0),
                    'status': trade['status'],
                    'reasoncodeid': trade.get('reasoncodeid', ''),
                    'last_comment': trade.get('last_comment', ''),
                    'high_level_code': None  # Will be filled in next step
                }
                
                ops_analysis.append(analysis_record)
            
            return pd.DataFrame(ops_analysis)
            
        except Exception as e:
            st.error(f"Error analyzing closed trades: {str(e)}")
            return pd.DataFrame()
    
    def _map_high_level_codes(self, ops_analysis, reason_code_mapping):
        """Map reason codes to high-level codes using substring matching"""
        try:
            if ops_analysis.empty or not reason_code_mapping:
                return ops_analysis
            
            # Apply high-level code mapping
            def get_high_level_code(reasoncodeid):
                if pd.isna(reasoncodeid) or reasoncodeid == '':
                    return 'Unknown'
                
                reasoncodeid_str = str(reasoncodeid).strip()
                
                # Try exact match first
                if reasoncodeid_str in reason_code_mapping:
                    return reason_code_mapping[reasoncodeid_str]
                
                # Try substring matching
                for reason_code, high_level_code in reason_code_mapping.items():
                    if reason_code in reasoncodeid_str or reasoncodeid_str in reason_code:
                        return high_level_code
                
                return 'Unknown'
            
            ops_analysis['high_level_code'] = ops_analysis['reasoncodeid'].apply(get_high_level_code)
            
            return ops_analysis
            
        except Exception as e:
            st.error(f"Error mapping high-level codes: {str(e)}")
            return ops_analysis
    
    def create_reason_code_summary(self, ops_analysis):
        """Create summary statistics for reason codes"""
        try:
            if ops_analysis.empty:
                return pd.DataFrame()
            
            # Group by high-level code
            summary = ops_analysis.groupby('high_level_code').agg({
                'trade_id': 'count',
                'deviationpercent': ['mean', 'max'],
                'threshold_used': 'mean'
            }).reset_index()
            
            # Flatten column names
            summary.columns = [
                'high_level_code',
                'trade_count',
                'avg_deviation',
                'max_deviation',
                'avg_threshold'
            ]
            
            # Sort by trade count descending
            summary = summary.sort_values('trade_count', ascending=False)
            
            return summary
            
        except Exception as e:
            st.error(f"Error creating reason code summary: {str(e)}")
            return pd.DataFrame()
    
    def create_legal_entity_ops_summary(self, ops_analysis):
        """Create ops summary by legal entity"""
        try:
            if ops_analysis.empty:
                return pd.DataFrame()
            
            # Group by legal entity and source system
            summary = ops_analysis.groupby(['legal_entity', 'source_system']).agg({
                'trade_id': 'count',
                'high_level_code': lambda x: x.value_counts().index[0] if len(x) > 0 else 'Unknown'
            }).reset_index()
            
            summary.columns = ['legal_entity', 'source_system', 'closed_trades', 'top_reason_code']
            
            return summary
            
        except Exception as e:
            st.error(f"Error creating legal entity ops summary: {str(e)}")
            return pd.DataFrame()
