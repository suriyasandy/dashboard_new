import requests
import pandas as pd
import io
import gzip
import os
from datetime import datetime
import streamlit as st

class APIClient:
    """Handle API calls for trade and exception data"""
    
    def __init__(self):
        self.base_url = os.getenv("API_BASE_URL", "https://api.example.com")
        self.oauth_token = None
        self.session = requests.Session()
    
    def authenticate(self):
        """Authenticate using OAuth"""
        try:
            client_id = os.getenv("OAUTH_CLIENT_ID", "default_client_id")
            client_secret = os.getenv("OAUTH_CLIENT_SECRET", "default_client_secret")
            
            auth_url = f"{self.base_url}/oauth/token"
            auth_data = {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret
            }
            
            response = requests.post(auth_url, data=auth_data)
            response.raise_for_status()
            
            token_data = response.json()
            self.oauth_token = token_data.get("access_token")
            
            # Set authorization header for all subsequent requests
            self.session.headers.update({
                "Authorization": f"Bearer {self.oauth_token}"
            })
            
            return True
            
        except Exception as e:
            st.error(f"Authentication failed: {str(e)}")
            return False
    
    def download_trade_data(self, task):
        """Download trade data for UAT and PROD"""
        try:
            if not self.oauth_token:
                if not self.authenticate():
                    raise Exception("Authentication failed")
            
            product_type = task['product_type']
            legal_entity = task['legal_entity']
            source_system = task['source_system']
            start_date = task['start_date'].strftime('%Y%m%d')
            end_date = task['end_date'].strftime('%Y%m%d')
            
            # Download UAT data
            uat_filename = f"{product_type}_{legal_entity}_{source_system}_{start_date}_{end_date}.gz"
            uat_url = f"{self.base_url}/trade-data/uat/{uat_filename}"
            uat_data = self._download_and_parse_gzip(uat_url)
            
            # Download PROD data
            prod_filename = f"{product_type}_{legal_entity}_{source_system}_{start_date}_{end_date}.gz"
            prod_url = f"{self.base_url}/trade-data/prod/{prod_filename}"
            prod_data = self._download_and_parse_gzip(prod_url)
            
            return uat_data, prod_data
            
        except Exception as e:
            st.warning(f"Failed to download trade data: {str(e)}")
            return pd.DataFrame(), pd.DataFrame()
    
    def download_exception_data(self, start_date, end_date):
        """Download exception data"""
        try:
            if not self.oauth_token:
                if not self.authenticate():
                    raise Exception("Authentication failed")
            
            url = f"{self.base_url}/exception-data"
            params = {
                "start_date": start_date.strftime('%Y-%m-%d'),
                "end_date": end_date.strftime('%Y-%m-%d')
            }
            
            response = self.session.get(url, params=params)
            response.raise_for_status()
            
            # Parse CSV response
            csv_data = io.StringIO(response.text)
            df = pd.read_csv(csv_data)
            
            return df
            
        except Exception as e:
            st.warning(f"Failed to download exception data: {str(e)}")
            return pd.DataFrame()
    
    def _download_and_parse_gzip(self, url):
        """Download and parse gzipped CSV file"""
        try:
            response = self.session.get(url, stream=True)
            response.raise_for_status()
            
            # Decompress gzip content
            with gzip.GzipFile(fileobj=io.BytesIO(response.content)) as gz_file:
                csv_content = gz_file.read().decode('utf-8')
            
            # Parse CSV
            csv_data = io.StringIO(csv_content)
            df = pd.read_csv(csv_data)
            
            return df
            
        except Exception as e:
            raise Exception(f"Failed to download/parse {url}: {str(e)}")
