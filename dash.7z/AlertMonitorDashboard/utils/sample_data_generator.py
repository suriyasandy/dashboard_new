import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta
import random
import os

class SampleDataGenerator:
    """Generate comprehensive sample data for testing the GFX dashboard"""
    
    def __init__(self):
        self.base_dir = "sample_data"
        os.makedirs(self.base_dir, exist_ok=True)
        
        # Configuration
        self.product_types = ["FX_SPOT", "FX_FORWARD", "FX_SWAP", "FX_OPTION"]
        self.legal_entities = ["Entity1", "Entity2", "Entity3"]
        self.source_systems = ["SYSTEM_A", "SYSTEM_B", "SYSTEM_C"]
        self.currency_pairs = [
            "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD",
            "NZDUSD", "EURGBP", "EURJPY", "GBPJPY", "CHFJPY", "EURAUD",
            "AUDCAD", "AUDCHF", "AUDJPY", "CADCHF", "CADJPY", "EURCHF",
            "EURNZD", "GBPAUD", "GBPCAD", "GBPCHF", "GBPNZD", "NZDCAD",
            "NZDCHF", "NZDJPY"
        ]
        
        # Date range after 2025
        self.start_date = date(2025, 1, 1)
        self.end_date = date(2025, 3, 31)
    
    def generate_trade_data(self, num_records=5000):
        """Generate comprehensive trade data with proper structure"""
        
        data = []
        
        for i in range(num_records):
            ccypair = random.choice(self.currency_pairs)
            ccy1, ccy2 = ccypair[:3], ccypair[3:]
            
            # Generate trade record
            trade_record = {
                'trade_id': f"TRD{str(i+1).zfill(8)}",
                'trade_date': self._random_date(),
                'business_date': self._random_date(),
                'ccypair': ccypair,
                'ccy1': ccy1,
                'ccy2': ccy2,
                'legal_entity': random.choice(self.legal_entities),
                'product_type': random.choice(self.product_types),
                'source_system': random.choice(self.source_systems),
                'notional_amount': round(random.uniform(100000, 10000000), 2),
                'deviationpercent': round(random.uniform(0.01, 5.0), 4),
                'alert_description': random.choice([
                    'Threshold breach detected',
                    'Price deviation alert',
                    'Volume anomaly',
                    'Rate variance detected',
                    'out of scope trade',  # Some out of scope
                    'Pricing alert triggered'
                ]),
                'trader_id': f"TRADER{random.randint(1, 50):03d}",
                'desk': random.choice(['FX_SPOT_DESK', 'FX_FORWARD_DESK', 'FX_OPTION_DESK']),
                'region': random.choice(['APAC', 'EMEA', 'AMERICAS']),
                'settlement_date': self._random_date(future=True),
                'market_price': round(random.uniform(0.5, 2.0), 6),
                'executed_price': round(random.uniform(0.5, 2.0), 6),
                'price_source': random.choice(['BLOOMBERG', 'REUTERS', 'INTERNAL']),
                'risk_factor': round(random.uniform(0.1, 3.0), 3)
            }
            
            data.append(trade_record)
        
        return pd.DataFrame(data)
    
    def generate_exception_data(self, num_records=2000):
        """Generate exception data for ops workflow analysis"""
        
        data = []
        reason_codes = [
            'RC001_PRICE_VALIDATION_FAILED',
            'RC002_SETTLEMENT_DELAY',
            'RC003_COUNTERPARTY_ISSUE',
            'RC004_REGULATORY_HOLD',
            'RC005_MARKET_DATA_ISSUE',
            'RC006_SYSTEM_ERROR',
            'RC007_MANUAL_REVIEW_REQUIRED',
            'RC008_CREDIT_LIMIT_BREACH',
            'RC009_COMPLIANCE_CHECK',
            'RC010_DOCUMENTATION_MISSING'
        ]
        
        high_level_codes = {
            'RC001': 'PRICING_ISSUES',
            'RC002': 'SETTLEMENT_ISSUES', 
            'RC003': 'COUNTERPARTY_ISSUES',
            'RC004': 'REGULATORY_ISSUES',
            'RC005': 'DATA_ISSUES',
            'RC006': 'SYSTEM_ISSUES',
            'RC007': 'MANUAL_PROCESS',
            'RC008': 'CREDIT_ISSUES',
            'RC009': 'COMPLIANCE_ISSUES',
            'RC010': 'DOCUMENTATION_ISSUES'
        }
        
        for i in range(num_records):
            reason_code = random.choice(reason_codes)
            reason_id = reason_code.split('_')[0]
            
            exception_record = {
                'trade_id': f"TRD{random.randint(1, 5000):08d}",
                'exception_id': f"EXC{str(i+1).zfill(8)}",
                'business_date': self._random_date(),
                'created_date': self._random_date(),
                'closed_date': self._random_date(future=True) if random.random() > 0.3 else None,
                'reasoncodeid': reason_code,
                'high_level_code': high_level_codes.get(reason_id, 'OTHER'),
                'exception_status': random.choice(['OPEN', 'CLOSED', 'IN_PROGRESS', 'RESOLVED']),
                'assigned_to': f"OPS_USER_{random.randint(1, 20):03d}",
                'priority': random.choice(['HIGH', 'MEDIUM', 'LOW']),
                'legal_entity': random.choice(self.legal_entities),
                'source_system': random.choice(self.source_systems),
                'resolution_comment': random.choice([
                    'Resolved after price validation',
                    'Counterparty confirmed',
                    'Manual override applied',
                    'System issue fixed',
                    'Documentation provided',
                    None
                ]),
                'processing_time': round(random.uniform(0.5, 10.0), 1)
            }
            
            data.append(exception_record)
        
        return pd.DataFrame(data)
    
    def generate_threshold_config(self):
        """Generate threshold configuration data"""
        
        currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD', 'NZD', 'SEK', 'NOK']
        
        data = []
        
        # Generate for each legal entity and currency combination
        for legal_entity in self.legal_entities + ['ALL']:
            for currency in currencies:
                threshold_record = {
                    'LegalEntity': legal_entity,
                    'CCY': currency,
                    'Original_Group': random.choice(['Group1', 'Group2', 'Group3']),
                    'Original_Threshold': round(random.uniform(0.5, 2.0), 2),
                    'Proposed_Group': random.choice(['Group1', 'Group2', 'Group3']),
                    'Proposed_Threshold': round(random.uniform(0.3, 1.5), 2)
                }
                
                # Add derived columns
                threshold_record['Adjusted_Group'] = threshold_record['Proposed_Group']
                threshold_record['Adjusted_Threshold'] = threshold_record['Proposed_Threshold']
                
                data.append(threshold_record)
        
        return pd.DataFrame(data)
    
    def generate_reason_code_mapping(self):
        """Generate reason code mapping for high-level categorization"""
        
        data = [
            {'reasoncodeid': 'RC001_PRICE_VALIDATION_FAILED', 'high_level_code': 'PRICING_ISSUES', 'description': 'Price validation failures'},
            {'reasoncodeid': 'RC002_SETTLEMENT_DELAY', 'high_level_code': 'SETTLEMENT_ISSUES', 'description': 'Settlement processing delays'},
            {'reasoncodeid': 'RC003_COUNTERPARTY_ISSUE', 'high_level_code': 'COUNTERPARTY_ISSUES', 'description': 'Counterparty related problems'},
            {'reasoncodeid': 'RC004_REGULATORY_HOLD', 'high_level_code': 'REGULATORY_ISSUES', 'description': 'Regulatory compliance holds'},
            {'reasoncodeid': 'RC005_MARKET_DATA_ISSUE', 'high_level_code': 'DATA_ISSUES', 'description': 'Market data quality issues'},
            {'reasoncodeid': 'RC006_SYSTEM_ERROR', 'high_level_code': 'SYSTEM_ISSUES', 'description': 'System processing errors'},
            {'reasoncodeid': 'RC007_MANUAL_REVIEW_REQUIRED', 'high_level_code': 'MANUAL_PROCESS', 'description': 'Manual review processes'},
            {'reasoncodeid': 'RC008_CREDIT_LIMIT_BREACH', 'high_level_code': 'CREDIT_ISSUES', 'description': 'Credit limit violations'},
            {'reasoncodeid': 'RC009_COMPLIANCE_CHECK', 'high_level_code': 'COMPLIANCE_ISSUES', 'description': 'Compliance verification'},
            {'reasoncodeid': 'RC010_DOCUMENTATION_MISSING', 'high_level_code': 'DOCUMENTATION_ISSUES', 'description': 'Missing documentation'}
        ]
        
        return pd.DataFrame(data)
    
    def _random_date(self, future=False):
        """Generate random date within the specified range"""
        
        if future:
            # Future dates for settlement
            start = self.start_date
            end = self.end_date + timedelta(days=90)
        else:
            start = self.start_date
            end = self.end_date
        
        time_between = end - start
        days_between = time_between.days
        random_days = random.randrange(days_between)
        
        return start + timedelta(days=random_days)
    
    def create_individual_trade_files(self):
        """Create individual trade files for each product type, legal entity, source system combination"""
        
        # Generate master trade data
        master_trade_data = self.generate_trade_data(num_records=15000)
        
        files_created = []
        
        for product_type in self.product_types:
            for legal_entity in self.legal_entities:
                for source_system in self.source_systems:
                    # Filter data for this combination
                    filtered_data = master_trade_data[
                        (master_trade_data['product_type'] == product_type) &
                        (master_trade_data['legal_entity'] == legal_entity) &
                        (master_trade_data['source_system'] == source_system)
                    ].copy()
                    
                    if not filtered_data.empty:
                        # Create filename with date range
                        start_str = self.start_date.strftime('%Y%m%d')
                        end_str = self.end_date.strftime('%Y%m%d')
                        filename = f"{product_type}_{legal_entity}_{source_system}_{start_str}_{end_str}.csv"
                        filepath = os.path.join(self.base_dir, filename)
                        
                        # Save file
                        filtered_data.to_csv(filepath, index=False)
                        files_created.append(filename)
        
        return files_created
    
    def create_all_sample_files(self):
        """Create all sample files needed for testing"""
        
        files_created = {}
        
        # Individual trade files
        files_created['trade_files'] = self.create_individual_trade_files()
        
        # Exception data
        exception_data = self.generate_exception_data(num_records=3000)
        exception_file = os.path.join(self.base_dir, "exception_data_sample.csv")
        exception_data.to_csv(exception_file, index=False)
        files_created['exception_file'] = "exception_data_sample.csv"
        
        # Threshold configuration
        threshold_config = self.generate_threshold_config()
        threshold_file = os.path.join(self.base_dir, "threshold_config_sample.csv")
        threshold_config.to_csv(threshold_file, index=False)
        files_created['threshold_file'] = "threshold_config_sample.csv"
        
        # Reason code mapping
        reason_mapping = self.generate_reason_code_mapping()
        reason_file = os.path.join(self.base_dir, "reason_codes_sample.csv")
        reason_mapping.to_csv(reason_file, index=False)
        files_created['reason_code_file'] = "reason_codes_sample.csv"
        
        return files_created
    
    def get_sample_statistics(self):
        """Get statistics about generated sample data"""
        
        stats = {}
        
        try:
            # Count trade files
            trade_files = [f for f in os.listdir(self.base_dir) if f.startswith(('FX_SPOT', 'FX_FORWARD', 'FX_SWAP', 'FX_OPTION'))]
            stats['trade_files_count'] = len(trade_files)
            
            # Load and analyze a sample trade file
            if trade_files:
                sample_file = os.path.join(self.base_dir, trade_files[0])
                sample_df = pd.read_csv(sample_file)
                stats['sample_records_per_file'] = len(sample_df)
                stats['total_estimated_records'] = len(trade_files) * len(sample_df)
                stats['currency_pairs'] = sample_df['ccypair'].nunique() if 'ccypair' in sample_df.columns else 0
            
            # Exception data statistics
            exception_file = os.path.join(self.base_dir, "exception_data_sample.csv")
            if os.path.exists(exception_file):
                exception_df = pd.read_csv(exception_file)
                stats['exception_records'] = len(exception_df)
                stats['unique_reason_codes'] = exception_df['reasoncodeid'].nunique() if 'reasoncodeid' in exception_df.columns else 0
            
            # Threshold configuration
            threshold_file = os.path.join(self.base_dir, "threshold_config_sample.csv")
            if os.path.exists(threshold_file):
                threshold_df = pd.read_csv(threshold_file)
                stats['threshold_configurations'] = len(threshold_df)
            
            stats['date_range'] = f"{self.start_date} to {self.end_date}"
            
        except Exception as e:
            stats['error'] = str(e)
        
        return stats

def generate_sample_data():
    """Main function to generate all sample data"""
    
    generator = SampleDataGenerator()
    
    print("Generating comprehensive sample data for GFX dashboard testing...")
    print(f"Date range: {generator.start_date} to {generator.end_date}")
    
    # Create all sample files
    files_created = generator.create_all_sample_files()
    
    # Get statistics
    stats = generator.get_sample_statistics()
    
    print(f"\nSample data generation completed!")
    print(f"Trade files created: {len(files_created['trade_files'])}")
    print(f"Total estimated trade records: {stats.get('total_estimated_records', 'Unknown')}")
    print(f"Exception records: {stats.get('exception_records', 'Unknown')}")
    print(f"Threshold configurations: {stats.get('threshold_configurations', 'Unknown')}")
    print(f"Currency pairs: {stats.get('currency_pairs', 'Unknown')}")
    
    return files_created, stats

if __name__ == "__main__":
    generate_sample_data()