import streamlit as st
import pandas as pd
import io
from datetime import datetime, date, timedelta

def initialize_session_state():
    """Initialize session state variables"""
    
    # Data storage
    if 'trade_data' not in st.session_state:
        st.session_state.trade_data = pd.DataFrame()
    
    if 'exception_data' not in st.session_state:
        st.session_state.exception_data = pd.DataFrame()
    
    if 'threshold_df' not in st.session_state:
        st.session_state.threshold_df = pd.DataFrame()
    
    if 'alerts_df' not in st.session_state:
        st.session_state.alerts_df = pd.DataFrame()
    
    if 'groupwise_summary' not in st.session_state:
        st.session_state.groupwise_summary = pd.DataFrame()
    
    if 'expanded_summary' not in st.session_state:
        st.session_state.expanded_summary = pd.DataFrame()
    
    if 'legal_entity_summary' not in st.session_state:
        st.session_state.legal_entity_summary = pd.DataFrame()
    
    if 'ops_analysis' not in st.session_state:
        st.session_state.ops_analysis = pd.DataFrame()
    
    # UI state
    if 'selected_bucket' not in st.session_state:
        st.session_state.selected_bucket = None
    
    if 'data_loaded' not in st.session_state:
        st.session_state.data_loaded = False
    
    if 'refresh_data' not in st.session_state:
        st.session_state.refresh_data = False
    
    if 'refresh_exception_data' not in st.session_state:
        st.session_state.refresh_exception_data = False

def export_dataframe(df, filename, file_format='csv'):
    """Export dataframe to various formats"""
    try:
        if df.empty:
            st.warning("No data to export")
            return None
        
        if file_format.lower() == 'csv':
            output = io.StringIO()
            df.to_csv(output, index=False)
            data = output.getvalue()
            mime_type = 'text/csv'
            file_extension = '.csv'
        
        elif file_format.lower() == 'excel':
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                df.to_excel(writer, index=False, sheet_name='Data')
            data = output.getvalue()
            mime_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            file_extension = '.xlsx'
        
        else:
            st.error(f"Unsupported file format: {file_format}")
            return None
        
        return {
            'data': data,
            'filename': f"{filename}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{file_extension}",
            'mime_type': mime_type
        }
        
    except Exception as e:
        st.error(f"Error exporting data: {str(e)}")
        return None

def format_number(value, decimal_places=2):
    """Format numbers for display"""
    try:
        if pd.isna(value):
            return "N/A"
        
        if isinstance(value, (int, float)):
            if value == float('inf'):
                return "∞"
            elif value == float('-inf'):
                return "-∞"
            else:
                return f"{value:.{decimal_places}f}"
        
        return str(value)
        
    except:
        return str(value)

def format_percentage(value, decimal_places=2):
    """Format percentages for display"""
    try:
        if pd.isna(value):
            return "N/A"
        
        if isinstance(value, (int, float)):
            return f"{value:.{decimal_places}f}%"
        
        return str(value)
        
    except:
        return str(value)

def create_download_button(df, filename, label, file_format='csv', key=None):
    """Create a download button for dataframes"""
    try:
        export_data = export_dataframe(df, filename, file_format)
        
        if export_data:
            return st.download_button(
                label=label,
                data=export_data['data'],
                file_name=export_data['filename'],
                mime=export_data['mime_type'],
                key=key
            )
        
        return None
        
    except Exception as e:
        st.error(f"Error creating download button: {str(e)}")
        return None

def validate_date_range(start_date, end_date):
    """Validate date range inputs"""
    errors = []
    
    if start_date > end_date:
        errors.append("Start date must be before end date")
    
    if end_date > date.today():
        errors.append("End date cannot be in the future")
    
    # Check for reasonable date range (not too far in the past)
    max_days_back = 365  # 1 year
    earliest_allowed = date.today() - timedelta(days=max_days_back)
    
    if start_date < earliest_allowed:
        errors.append(f"Start date cannot be more than {max_days_back} days ago")
    
    return errors

def get_default_date_range():
    """Get default date range for the application"""
    end_date = date.today()
    start_date = end_date - timedelta(days=30)  # Default to last 30 days
    
    return start_date, end_date

def parse_bucket_range(bucket_label):
    """Parse bucket range from label"""
    try:
        if ' - ' in bucket_label:
            parts = bucket_label.split(' - ')
            lower_bound = float(parts[0])
            
            if parts[1] == 'inf':
                upper_bound = float('inf')
            else:
                upper_bound = float(parts[1])
            
            return lower_bound, upper_bound
        
        return None, None
        
    except:
        return None, None

def filter_alerts_by_bucket(alerts_df, bucket_label):
    """Filter alerts dataframe by bucket range"""
    try:
        lower_bound, upper_bound = parse_bucket_range(bucket_label)
        
        if lower_bound is None or upper_bound is None:
            return pd.DataFrame()
        
        # Filter alerts within the bucket range
        if upper_bound == float('inf'):
            filtered_alerts = alerts_df[alerts_df['deviationpercent'] > lower_bound]
        else:
            filtered_alerts = alerts_df[
                (alerts_df['deviationpercent'] > lower_bound) &
                (alerts_df['deviationpercent'] <= upper_bound)
            ]
        
        return filtered_alerts
        
    except Exception as e:
        st.error(f"Error filtering alerts by bucket: {str(e)}")
        return pd.DataFrame()

def calculate_summary_statistics(df, column):
    """Calculate summary statistics for a column"""
    try:
        if df.empty or column not in df.columns:
            return {}
        
        stats = {
            'count': len(df),
            'mean': df[column].mean(),
            'median': df[column].median(),
            'std': df[column].std(),
            'min': df[column].min(),
            'max': df[column].max(),
            'q25': df[column].quantile(0.25),
            'q75': df[column].quantile(0.75)
        }
        
        return stats
        
    except Exception as e:
        st.error(f"Error calculating statistics: {str(e)}")
        return {}
