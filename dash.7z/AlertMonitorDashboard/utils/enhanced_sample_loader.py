import pandas as pd
import streamlit as st
import os
from datetime import datetime, date
import glob

class EnhancedSampleLoader:
    """Enhanced sample data loader for testing the GFX dashboard with 2025+ data"""
    
    def __init__(self):
        self.sample_data_dir = "sample_data"
        self.available_files = self._scan_available_files()
    
    def _scan_available_files(self):
        """Scan and categorize available sample files"""
        files = {
            'trade_files': {},
            'exception_file': None,
            'threshold_file': None,
            'reason_code_file': None
        }
        
        if not os.path.exists(self.sample_data_dir):
            return files
        
        # Scan trade files
        trade_pattern = os.path.join(self.sample_data_dir, "FX_*.csv")
        trade_files = glob.glob(trade_pattern)
        
        for filepath in trade_files:
            filename = os.path.basename(filepath)
            # Extract components: FX_SPOT_Entity1_SYSTEM_A_20250101_20250331.csv
            parts = filename.replace('.csv', '').split('_')
            if len(parts) >= 6:  # Need at least 6 parts for FX_SPOT_Entity1_SYSTEM_A_date_date format
                product_type = parts[0] + '_' + parts[1]  # FX_SPOT, FX_FORWARD, etc.
                legal_entity = parts[2]  # Entity1, Entity2, Entity3
                source_system = parts[3] + '_' + parts[4]  # SYSTEM_A, SYSTEM_B, SYSTEM_C
                key = f"{product_type}_{legal_entity}_{source_system}"
                files['trade_files'][key] = filepath
        
        # Scan other files
        exception_file = os.path.join(self.sample_data_dir, "exception_data_sample.csv")
        if os.path.exists(exception_file):
            files['exception_file'] = exception_file
        
        threshold_file = os.path.join(self.sample_data_dir, "threshold_config_sample.csv")
        if os.path.exists(threshold_file):
            files['threshold_file'] = threshold_file
        
        reason_file = os.path.join(self.sample_data_dir, "reason_codes_sample.csv")
        if os.path.exists(reason_file):
            files['reason_code_file'] = reason_file
        
        return files
    
    def load_sample_trade_data(self, sidebar_data):
        """Load sample trade data based on sidebar selections"""
        try:
            product_types = sidebar_data.get('product_types', ['FX_SPOT'])
            legal_entities = sidebar_data.get('legal_entities', ['Entity1'])
            source_systems = sidebar_data.get('source_systems', ['SYSTEM_A'])
            
            all_trade_data = []
            loaded_files = []
            
            # Load data for each selected combination
            for product_type in product_types:
                for legal_entity in legal_entities:
                    for source_system in source_systems:
                        key = f"{product_type}_{legal_entity}_{source_system}"
                        
                        if key in self.available_files['trade_files']:
                            filepath = self.available_files['trade_files'][key]
                            try:
                                trade_data = pd.read_csv(filepath)
                                
                                # Convert date columns
                                if 'trade_date' in trade_data.columns:
                                    trade_data['trade_date'] = pd.to_datetime(trade_data['trade_date'])
                                if 'business_date' in trade_data.columns:
                                    trade_data['business_date'] = pd.to_datetime(trade_data['business_date'])
                                
                                all_trade_data.append(trade_data)
                                loaded_files.append(os.path.basename(filepath))
                                
                            except Exception as e:
                                st.warning(f"Error loading {filepath}: {str(e)}")
            
            if all_trade_data:
                combined_data = pd.concat(all_trade_data, ignore_index=True)
                
                # Apply date filtering if specified
                start_date = sidebar_data.get('start_date')
                end_date = sidebar_data.get('end_date')
                
                if start_date and end_date and 'trade_date' in combined_data.columns:
                    start_datetime = pd.to_datetime(start_date)
                    end_datetime = pd.to_datetime(end_date)
                    
                    combined_data = combined_data[
                        (combined_data['trade_date'] >= start_datetime) &
                        (combined_data['trade_date'] <= end_datetime)
                    ]
                
                st.success(f"✅ Loaded {len(combined_data)} trade records from {len(loaded_files)} files")
                st.info(f"Files loaded: {', '.join(loaded_files[:5])}{'...' if len(loaded_files) > 5 else ''}")
                
                return combined_data
            else:
                st.warning("⚠️ No trade data files found for selected criteria")
                return pd.DataFrame()
            
        except Exception as e:
            st.error(f"Error loading sample trade data: {str(e)}")
            return pd.DataFrame()
    
    def load_sample_exception_data(self, sidebar_data):
        """Load sample exception data"""
        try:
            if not self.available_files['exception_file']:
                st.warning("No exception data sample file found")
                return pd.DataFrame()
            
            exception_data = pd.read_csv(self.available_files['exception_file'])
            
            # Convert date columns
            date_columns = ['business_date', 'created_date', 'closed_date']
            for col in date_columns:
                if col in exception_data.columns:
                    exception_data[col] = pd.to_datetime(exception_data[col], errors='coerce')
            
            # Filter by date range if specified
            start_date = sidebar_data.get('start_date')
            end_date = sidebar_data.get('end_date')
            
            if start_date and end_date and 'business_date' in exception_data.columns:
                start_datetime = pd.to_datetime(start_date)
                end_datetime = pd.to_datetime(end_date)
                
                exception_data = exception_data[
                    (exception_data['business_date'] >= start_datetime) &
                    (exception_data['business_date'] <= end_datetime)
                ]
            
            st.success(f"✅ Loaded {len(exception_data)} exception records")
            return exception_data
            
        except Exception as e:
            st.error(f"Error loading sample exception data: {str(e)}")
            return pd.DataFrame()
    
    def load_sample_threshold_config(self):
        """Load sample threshold configuration"""
        try:
            if not self.available_files['threshold_file']:
                st.warning("No threshold configuration sample file found")
                return pd.DataFrame()
            
            threshold_data = pd.read_csv(self.available_files['threshold_file'])
            st.success(f"✅ Loaded {len(threshold_data)} threshold configurations")
            return threshold_data
            
        except Exception as e:
            st.error(f"Error loading threshold configuration: {str(e)}")
            return pd.DataFrame()
    
    def load_sample_reason_codes(self):
        """Load sample reason code mapping"""
        try:
            if not self.available_files['reason_code_file']:
                st.warning("No reason code mapping sample file found")
                return pd.DataFrame()
            
            reason_data = pd.read_csv(self.available_files['reason_code_file'])
            st.success(f"✅ Loaded {len(reason_data)} reason code mappings")
            return reason_data
            
        except Exception as e:
            st.error(f"Error loading reason code mapping: {str(e)}")
            return pd.DataFrame()
    
    def get_available_options(self):
        """Get available options from sample data for sidebar configuration"""
        try:
            options = {
                'product_types': [],
                'legal_entities': [],
                'source_systems': [],
                'date_range': None
            }
            
            # Extract unique values from trade file keys
            for key in self.available_files['trade_files'].keys():
                parts = key.split('_')
                if len(parts) >= 5:  # FX_SPOT_Entity1_SYSTEM_A format
                    product_type = parts[0] + '_' + parts[1]  # FX_SPOT
                    legal_entity = parts[2]  # Entity1
                    source_system = parts[3] + '_' + parts[4]  # SYSTEM_A
                    
                    if product_type not in options['product_types']:
                        options['product_types'].append(product_type)
                    if legal_entity not in options['legal_entities']:
                        options['legal_entities'].append(legal_entity)
                    if source_system not in options['source_systems']:
                        options['source_systems'].append(source_system)
            
            # Get date range from a sample file
            if self.available_files['trade_files']:
                sample_file = list(self.available_files['trade_files'].values())[0]
                sample_data = pd.read_csv(sample_file, nrows=100)
                
                if 'trade_date' in sample_data.columns:
                    sample_data['trade_date'] = pd.to_datetime(sample_data['trade_date'])
                    min_date = sample_data['trade_date'].min().date()
                    max_date = sample_data['trade_date'].max().date()
                    options['date_range'] = (min_date, max_date)
            
            return options
            
        except Exception as e:
            st.error(f"Error getting available options: {str(e)}")
            return self._get_default_options()
    
    def _get_default_options(self):
        """Get default options if sample data is not available"""
        return {
            'product_types': ['FX_SPOT', 'FX_FORWARD', 'FX_SWAP', 'FX_OPTION'],
            'legal_entities': ['Entity1', 'Entity2', 'Entity3'],
            'source_systems': ['SYSTEM_A', 'SYSTEM_B', 'SYSTEM_C'],
            'date_range': (date(2025, 1, 1), date(2025, 3, 31))
        }
    
    def check_sample_data_availability(self):
        """Check if all sample data files are available"""
        status = {
            'trade_files_count': len(self.available_files['trade_files']),
            'has_exception_data': self.available_files['exception_file'] is not None,
            'has_threshold_config': self.available_files['threshold_file'] is not None,
            'has_reason_codes': self.available_files['reason_code_file'] is not None,
            'all_available': False
        }
        
        status['all_available'] = (
            status['trade_files_count'] > 0 and
            status['has_exception_data'] and
            status['has_threshold_config'] and
            status['has_reason_codes']
        )
        
        return status
    
    def get_file_info(self):
        """Get detailed information about available files"""
        info = {
            'trade_files': list(self.available_files['trade_files'].keys()),
            'file_paths': {},
            'file_sizes': {}
        }
        
        # Get file sizes
        for category, files in self.available_files.items():
            if category == 'trade_files':
                for key, filepath in files.items():
                    if os.path.exists(filepath):
                        size_mb = os.path.getsize(filepath) / (1024 * 1024)
                        info['file_sizes'][key] = f"{size_mb:.2f} MB"
            else:
                if files and os.path.exists(files):
                    size_mb = os.path.getsize(files) / (1024 * 1024)
                    info['file_sizes'][category] = f"{size_mb:.2f} MB"
        
        info['file_paths'] = self.available_files
        
        return info