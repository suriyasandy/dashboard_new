import pandas as pd
import streamlit as st
import os
from datetime import datetime, date

class SampleDataLoader:
    """Load sample data for testing the GFX dashboard"""
    
    def __init__(self):
        self.sample_data_dir = "sample_data"
    
    def load_sample_trade_data(self, sidebar_data):
        """Load sample trade data based on sidebar selections"""
        try:
            # Load the sample trade data
            file_path = os.path.join(self.sample_data_dir, "trade_data_sample.csv")
            
            if not os.path.exists(file_path):
                st.error(f"Sample trade data file not found: {file_path}")
                return pd.DataFrame()
            
            trade_data = pd.read_csv(file_path)
            
            # Convert trade_date to datetime
            trade_data['trade_date'] = pd.to_datetime(trade_data['trade_date'])
            
            # Filter based on sidebar selections
            filtered_data = self._filter_trade_data(trade_data, sidebar_data)
            
            if not filtered_data.empty:
                st.success(f"✅ Loaded {len(filtered_data)} sample trade records")
            else:
                st.warning("⚠️ No trades match the selected criteria")
            
            return filtered_data
            
        except Exception as e:
            st.error(f"Error loading sample trade data: {str(e)}")
            return pd.DataFrame()
    
    def load_sample_exception_data(self, sidebar_data):
        """Load sample exception data"""
        try:
            file_path = os.path.join(self.sample_data_dir, "exception_data_sample.csv")
            
            if not os.path.exists(file_path):
                st.error(f"Sample exception data file not found: {file_path}")
                return pd.DataFrame()
            
            exception_data = pd.read_csv(file_path)
            
            # Convert processed_date to datetime
            exception_data['processed_date'] = pd.to_datetime(exception_data['processed_date'])
            
            # Filter by date range if specified
            start_date = sidebar_data.get('start_date')
            end_date = sidebar_data.get('end_date')
            
            if start_date and end_date:
                start_datetime = pd.to_datetime(start_date)
                end_datetime = pd.to_datetime(end_date)
                
                exception_data = exception_data[
                    (exception_data['processed_date'] >= start_datetime) &
                    (exception_data['processed_date'] <= end_datetime)
                ]
            
            if not exception_data.empty:
                st.success(f"✅ Loaded {len(exception_data)} sample exception records")
            else:
                st.warning("⚠️ No exception data found for selected date range")
                
            return exception_data
            
        except Exception as e:
            st.error(f"Error loading sample exception data: {str(e)}")
            return pd.DataFrame()
    
    def _filter_trade_data(self, trade_data, sidebar_data):
        """Filter trade data based on sidebar selections"""
        filtered_data = trade_data.copy()
        
        # Filter by product types
        product_types = sidebar_data.get('product_types', [])
        if product_types:
            filtered_data = filtered_data[filtered_data['product_type'].isin(product_types)]
        
        # Filter by legal entities
        legal_entities = sidebar_data.get('legal_entities', [])
        if legal_entities:
            filtered_data = filtered_data[filtered_data['legal_entity'].isin(legal_entities)]
        
        # Filter by source systems
        source_systems = sidebar_data.get('source_systems', [])
        if source_systems:
            filtered_data = filtered_data[filtered_data['source_system'].isin(source_systems)]
        
        # Filter by date range
        start_date = sidebar_data.get('start_date')
        end_date = sidebar_data.get('end_date')
        
        if start_date and end_date:
            start_datetime = pd.to_datetime(start_date)
            end_datetime = pd.to_datetime(end_date)
            
            filtered_data = filtered_data[
                (filtered_data['trade_date'] >= start_datetime) &
                (filtered_data['trade_date'] <= end_datetime)
            ]
        
        return filtered_data
    
    def get_available_options(self):
        """Get available options from sample data for sidebar configuration"""
        try:
            file_path = os.path.join(self.sample_data_dir, "trade_data_sample.csv")
            
            if not os.path.exists(file_path):
                return self._get_default_options()
            
            trade_data = pd.read_csv(file_path)
            
            options = {
                'product_types': sorted(trade_data['product_type'].unique().tolist()),
                'legal_entities': sorted(trade_data['legal_entity'].unique().tolist()),
                'source_systems': sorted(trade_data['source_system'].unique().tolist()),
                'currency_pairs': sorted(trade_data['ccypair'].unique().tolist())
            }
            
            return options
            
        except Exception as e:
            st.warning(f"Could not load sample data options: {str(e)}")
            return self._get_default_options()
    
    def _get_default_options(self):
        """Get default options if sample data is not available"""
        return {
            'product_types': ["FX_SPOT", "FX_FORWARD", "FX_SWAP", "FX_OPTION"],
            'legal_entities': ["Entity1", "Entity2", "Entity3", "ALL"],
            'source_systems': ["SYSTEM_A", "SYSTEM_B", "SYSTEM_C"],
            'currency_pairs': ["EURUSD", "GBPUSD", "USDJPY", "EURJPY", "GBPJPY", "USDCHF", "AUDUSD", "NZDUSD"]
        }
    
    def check_sample_data_availability(self):
        """Check if all sample data files are available"""
        required_files = [
            "trade_data_sample.csv",
            "exception_data_sample.csv",
            "threshold_config_sample.csv",
            "reason_codes_sample.csv"
        ]
        
        missing_files = []
        for file_name in required_files:
            file_path = os.path.join(self.sample_data_dir, file_name)
            if not os.path.exists(file_path):
                missing_files.append(file_name)
        
        return len(missing_files) == 0, missing_files
    
    def get_sample_file_path(self, file_type):
        """Get the path to a specific sample file"""
        file_mapping = {
            'threshold': 'threshold_config_sample.csv',
            'reason_codes': 'reason_codes_sample.csv',
            'trade_data': 'trade_data_sample.csv',
            'exception_data': 'exception_data_sample.csv'
        }
        
        if file_type in file_mapping:
            return os.path.join(self.sample_data_dir, file_mapping[file_type])
        
        return None